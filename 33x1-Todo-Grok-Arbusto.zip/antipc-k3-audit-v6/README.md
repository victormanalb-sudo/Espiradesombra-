# AntiPC-K3-Audit v6

Auditoría de integridad K3 con **reciclaje real de ALU** (estilo AntiPC) y derivación de clave inspirada en **encriptacionGeometrica**.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Novedades de v6

- **ALURecycler**: firma por K3 del contenido. Segunda pasada sobre los mismos datos → `alu_saved` aumenta y no se recalcula.
- Comando `audit --passes 2` demuestra el reciclaje en una sola ejecución.
- **geo_derive_key**: derivación de la clave de chat a partir de una semilla, usando un esquema simple de convergencia (pares de bits + mezcla K3, base 33). Inspirado en `encriptacionGeometrica`, no es un cifrado completo.
- Informe incluye `alu_executed` y `alu_saved`.

## Uso

```bash
# Demostrar reciclaje (segunda pasada debe mostrar alu_saved > 0)
python antipc_audit.py audit --dir . --out informe.json --passes 2

# Servidor (clave de chat derivada de la semilla)
python antipc_audit.py serve --dir /datos --tokens tokens.json --chat-seed 33x1-civil-vma

# Cliente chat
python antipc_audit.py client --token EL_TOKEN --chat-seed 33x1-civil-vma "CHAT hola"
```

## Sobre la encriptación geométrica

El módulo `encriptacionGeometrica` del monorepo es un motor de convergencia por perímetros y pares de bits con K3 (base 33, rel 1).  
Aquí se usa solo para **derivar material de clave** de forma determinista y civil. No sustituye TLS ni un cifrado de canal real.

## Principio

> Mover conocimiento, no recalcular ALU.

**VMA — AntiPC-K3-Audit v6 / 33×1** · Uso civil.
