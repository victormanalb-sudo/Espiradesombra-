"""
AntiPC-K3-Audit v6
Reciclaje de ALU real (estilo AntiPC KnowledgeResolver) + derivación de clave
inspirada en encriptacionGeometrica (convergencia / K3 base 33).
Uso civil · Víctor Manzanares Alberola (VMA) · 33×1
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import secrets
import socket
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

# ── Núcleo K3 ─────────────────────────────────────────────────────────────────

OFFSETS = (5, 7, 9, 11, 13, 17, 19, 23)
MAGICO = 0x9E3779B1
FINAL_MUL_A = 0x85EBCA6B
FINAL_MUL_B = 0xC2B2AE35


def _rotl32(value: int, positions: int) -> int:
    positions &= 31
    if positions == 0:
        return value & 0xFFFFFFFF
    value &= 0xFFFFFFFF
    return ((value << positions) | (value >> (32 - positions))) & 0xFFFFFFFF


def _ejecutar_compresion_k3(estado: list[int], valor_bloque: int, n: int) -> None:
    b = valor_bloque & 0xFFFFFFFF
    x = (estado[0] ^ (b & estado[1 % n])) & 0xFFFFFFFF
    for j in range(2, n):
        x ^= _rotl32(estado[j], OFFSETS[j % 8])
    x ^= _rotl32(estado[1 % n], OFFSETS[4])
    x = (x + _rotl32(estado[0], OFFSETS[5])) & 0xFFFFFFFF
    x ^= (b * MAGICO) & 0xFFFFFFFF
    x ^= b
    x = (x + _rotl32(b, OFFSETS[6])) & 0xFFFFFFFF
    x ^= _rotl32(b, OFFSETS[7])
    x ^= _rotl32(x, OFFSETS[2])
    x = (x * MAGICO) & 0xFFFFFFFF
    x ^= (x >> 15)
    estado_anterior_0 = estado[0]
    estado[0] = x & 0xFFFFFFFF
    temp_prev = estado_anterior_0
    for i in range(1, n):
        temp_actual = estado[i]
        estado[i] = (_rotl32(estado[i], OFFSETS[0] + i) ^ temp_prev) & 0xFFFFFFFF
        temp_prev = temp_actual
        if i == n - 1:
            estado[i] ^= b
            estado[i] &= 0xFFFFFFFF


def _extraer_hash_final(registros: list[int], n: int) -> int:
    acumulador = registros[0]
    for i in range(1, n):
        acumulador ^= _rotl32(registros[i], 5 + i)
        acumulador &= 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    acumulador = (acumulador * FINAL_MUL_A) & 0xFFFFFFFF
    acumulador ^= acumulador >> 13
    acumulador = (acumulador * FINAL_MUL_B) & 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    return acumulador & 0xFFFFFFFF


def k3_hash_buffer(data: bytes, seed: int = 0x1F2E3D4C) -> int:
    n = 4
    registros = [(seed ^ (i * MAGICO)) & 0xFFFFFFFF for i in range(n)]
    ancho = 4
    i = 0
    buffer_parcial = bytearray(4)
    bytes_en_buffer = 0
    while i < len(data):
        while bytes_en_buffer < ancho and i < len(data):
            buffer_parcial[bytes_en_buffer] = data[i]
            bytes_en_buffer += 1
            i += 1
        if bytes_en_buffer == ancho:
            bloque = 0
            for b in range(ancho):
                bloque = (bloque << 8) | buffer_parcial[b]
            _ejecutar_compresion_k3(registros, bloque, n)
            bytes_en_buffer = 0
    if bytes_en_buffer > 0:
        bloque = 0
        for b in range(ancho):
            byte = buffer_parcial[b] if b < bytes_en_buffer else 0
            bloque = (bloque << 8) | byte
        _ejecutar_compresion_k3(registros, bloque, n)
    return _extraer_hash_final(registros, n)


# ── Derivación de clave inspirada en encriptacionGeometrica ───────────────────
# Convergencia simple: pares de bits → perímetro acumulado → mezcla K3 (base 33, rel 1)

def geo_derive_key(seed: str, length: int = 32) -> bytes:
    """Derivación civil a partir de semilla, estilo convergencia geométrica + K3."""
    data = seed.encode("utf-8")
    acc = 33  # base 33
    for i, b in enumerate(data):
        pair = (b >> 6) & 3  # simula par de bits
        if pair == 0b10:
            acc += 1
        elif pair == 0b11:
            acc += 2
        elif pair == 0b00:
            acc += 3
        # 0b01 no aporta (paradoja)
        acc = (acc * 0x9E3779B1 + b) & 0xFFFFFFFF
    # mezcla final con K3
    k3 = k3_hash_buffer(data + acc.to_bytes(4, "little"))
    out = bytearray()
    state = k3
    while len(out) < length:
        state = k3_hash_buffer(state.to_bytes(4, "little") + data)
        out.extend(state.to_bytes(4, "little"))
    return bytes(out[:length])


# ── Reciclaje de ALU (estilo AntiPC) ──────────────────────────────────────────

class ALURecycler:
    """Equivalente simplificado del KnowledgeResolver + reuse de AntiPC.
    Firma = K3 del contenido. Segunda vez → 0 ALU.
    """
    def __init__(self) -> None:
        self._store: dict[str, dict] = {}  # signature -> result
        self.alu_executed = 0
        self.alu_saved = 0
        self._lock = threading.Lock()

    def signature(self, data: bytes) -> str:
        return f"{k3_hash_buffer(data):08X}"

    def get_or_compute(self, data: bytes, path: str) -> dict:
        sig = self.signature(data)
        with self._lock:
            if sig in self._store:
                self.alu_saved += 1
                return {**self._store[sig], "cached": True, "signature": sig}
            # compute
            k3 = int(sig, 16)
            sha = hashlib.sha256(data).hexdigest()
            result = {
                "path": path,
                "size": len(data),
                "k3": sig,
                "sha256": sha,
                "cached": False,
                "signature": sig,
            }
            self._store[sig] = result
            self.alu_executed += 1
            return result


# ── Tokens (igual v4/v5) ──────────────────────────────────────────────────────

@dataclass
class TokenInfo:
    role: str
    created: float
    expires: float
    revoked: bool = False


class TokenStore:
    def __init__(self) -> None:
        self.tokens: dict[str, TokenInfo] = {}

    def add(self, role: str = "auditor", ttl_seconds: int = 3600) -> str:
        token = secrets.token_hex(16)
        now = time.time()
        self.tokens[token] = TokenInfo(role=role, created=now, expires=now + ttl_seconds)
        return token

    def check(self, token: str) -> bool:
        info = self.tokens.get(token)
        if not info or info.revoked or time.time() > info.expires:
            return False
        return True

    def role_of(self, token: str) -> str | None:
        info = self.tokens.get(token)
        return info.role if info and self.check(token) else None

    def revoke(self, token: str) -> bool:
        if token in self.tokens:
            self.tokens[token].revoked = True
            return True
        return False

    def to_dict(self) -> dict:
        return {tok: asdict(info) for tok, info in self.tokens.items()}

    @classmethod
    def from_dict(cls, data: dict) -> "TokenStore":
        store = cls()
        for tok, info in data.get("tokens", {}).items():
            store.tokens[tok] = TokenInfo(**info)
        return store


def sign_message(key: bytes, msg: str) -> str:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).hexdigest()


def verify_message(key: bytes, msg: str, signature: str) -> bool:
    return hmac.compare_digest(sign_message(key, msg), signature)


# ── Auditoría con reciclaje ───────────────────────────────────────────────────

@dataclass
class AuditReport:
    version: str = "6.0.0"
    tool: str = "AntiPC-K3-Audit"
    author: str = "Víctor Manzanares Alberola (VMA) · 33×1"
    principle: str = "Mover conocimiento, no recalcular ALU"
    timestamp: str = ""
    root: str = ""
    files_scanned: int = 0
    files_hashed: int = 0
    alu_executed: int = 0
    alu_saved: int = 0
    duplicate_groups: int = 0
    bytes_recoverable: int = 0
    elapsed_s: float = 0.0
    workers: int = 1
    requester: str = ""
    entries: list[dict] = field(default_factory=list)
    groups: list[dict] = field(default_factory=list)
    manifesto_sha256: str = ""


def scan_directory(root: Path, max_files: int | None = None) -> list[Path]:
    files: list[Path] = []
    for p in root.rglob("*"):
        if p.is_file() and not p.name.startswith("."):
            files.append(p)
            if max_files and len(files) >= max_files:
                break
    return files


def run_audit(root: Path, recycler: ALURecycler | None = None, workers: int = 4,
              max_files: int | None = None, requester: str = "") -> AuditReport:
    if recycler is None:
        recycler = ALURecycler()
    t0 = time.perf_counter()
    paths = scan_directory(root, max_files)

    def task(p: Path) -> dict | None:
        try:
            data = p.read_bytes()
            return recycler.get_or_compute(data, str(p.relative_to(root)))
        except OSError:
            return None

    entries = []
    if workers <= 1:
        for p in paths:
            r = task(p)
            if r:
                entries.append(r)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for r in pool.map(task, paths):
                if r:
                    entries.append(r)

    groups_map: dict[str, list] = defaultdict(list)
    size_map: dict[str, int] = {}
    for e in entries:
        key = f"{e['size']}:{e['k3']}"
        groups_map[key].append(e["path"])
        size_map[key] = e["size"]
    groups = []
    bytes_recoverable = 0
    for key, plist in groups_map.items():
        if len(plist) > 1:
            sz = size_map[key]
            groups.append({"key": key, "count": len(plist), "total_bytes": sz * len(plist), "paths": plist})
            bytes_recoverable += sz * (len(plist) - 1)

    elapsed = time.perf_counter() - t0
    report = AuditReport(
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        root=str(root.resolve()),
        files_scanned=len(paths),
        files_hashed=len(entries),
        alu_executed=recycler.alu_executed,
        alu_saved=recycler.alu_saved,
        duplicate_groups=len(groups),
        bytes_recoverable=bytes_recoverable,
        elapsed_s=round(elapsed, 4),
        workers=workers,
        requester=requester,
        entries=entries,
        groups=groups,
    )
    payload = json.dumps({k: v for k, v in asdict(report).items() if k != "manifesto_sha256"},
                         sort_keys=True, ensure_ascii=False).encode()
    report.manifesto_sha256 = hashlib.sha256(payload).hexdigest()
    return report


def save_report(report: AuditReport, out: Path) -> None:
    out.write_text(json.dumps(asdict(report), indent=2, ensure_ascii=False), encoding="utf-8")


def verify_report(path: Path) -> bool:
    data = json.loads(path.read_text(encoding="utf-8"))
    claimed = data.pop("manifesto_sha256", None)
    if not claimed:
        return False
    payload = json.dumps(data, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest() == claimed


# ── Servidor / cliente (con clave derivada geo) ───────────────────────────────

def _recv_line(conn: socket.socket) -> str:
    data = b""
    while b"\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data += chunk
    return data.decode("utf-8", errors="ignore").strip()


def serve(host: str, port: int, root: Path, workers: int, tokens: TokenStore, chat_seed: str) -> None:
    recycler = ALURecycler()
    chat_key = geo_derive_key(chat_seed)
    print(f"AntiPC-K3-Audit v6 en {host}:{port}")
    print(f"Clave de chat derivada (geo+K3): {chat_key[:8].hex()}...")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(5)
        while True:
            conn, addr = s.accept()
            threading.Thread(target=_handle, args=(conn, addr, root, workers, tokens, recycler, chat_key), daemon=True).start()


def _handle(conn, addr, root, workers, tokens, recycler, chat_key):
    with conn:
        first = _recv_line(conn)
        if not first.startswith("AUTH ") or not tokens.check(first[5:].strip()):
            conn.sendall(b"DENIED\n")
            return
        role = tokens.role_of(first[5:].strip()) or "?"
        conn.sendall(b"OK\n")
        while True:
            line = _recv_line(conn)
            if not line or line == "QUIT":
                break
            if line == "AUDIT":
                report = run_audit(root, recycler=recycler, workers=workers, requester=f"{addr[0]}:{role}")
                conn.sendall(json.dumps(asdict(report)).encode() + b"\n")
            elif line == "STATS":
                stats = {"alu_executed": recycler.alu_executed, "alu_saved": recycler.alu_saved, "role": role}
                conn.sendall(json.dumps(stats).encode() + b"\n")
            elif line.startswith("CHAT "):
                try:
                    body, sig = line[5:].rsplit("|", 1)
                except ValueError:
                    conn.sendall(b"BAD\n")
                    continue
                if not verify_message(chat_key, body, sig):
                    conn.sendall(b"BAD_SIG\n")
                    continue
                reply = f"ECHO {body}"
                conn.sendall(f"{reply}|{sign_message(chat_key, reply)}\n".encode())
            else:
                conn.sendall(b"UNKNOWN\n")


def client(host: str, port: int, token: str, cmd: str, chat_seed: str) -> None:
    chat_key = geo_derive_key(chat_seed)
    with socket.create_connection((host, port), timeout=30) as s:
        s.sendall(f"AUTH {token}\n".encode())
        if _recv_line(s) != "OK":
            print("DENIED")
            return
        if cmd.startswith("CHAT "):
            body = cmd[5:]
            sig = sign_message(chat_key, body)
            s.sendall(f"CHAT {body}|{sig}\n".encode())
        else:
            s.sendall((cmd + "\n").encode())
        print(_recv_line(s))


def main() -> int:
    parser = argparse.ArgumentParser(description="AntiPC-K3-Audit v6 · VMA / 33×1 · uso civil")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_audit = sub.add_parser("audit")
    p_audit.add_argument("--dir", required=True, type=Path)
    p_audit.add_argument("--out", required=True, type=Path)
    p_audit.add_argument("--workers", type=int, default=4)
    p_audit.add_argument("--passes", type=int, default=1, help="pasadas para demostrar reciclaje ALU")

    p_verify = sub.add_parser("verify")
    p_verify.add_argument("informe", type=Path)

    p_token = sub.add_parser("token")
    p_token.add_argument("--role", choices=["auditor", "admin"], default="auditor")
    p_token.add_argument("--ttl", type=int, default=3600)
    p_token.add_argument("--out", type=Path, default=Path("tokens.json"))

    p_revoke = sub.add_parser("revoke")
    p_revoke.add_argument("token")
    p_revoke.add_argument("--tokens", type=Path, default=Path("tokens.json"))

    p_serve = sub.add_parser("serve")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=9333)
    p_serve.add_argument("--dir", required=True, type=Path)
    p_serve.add_argument("--workers", type=int, default=4)
    p_serve.add_argument("--tokens", type=Path, default=Path("tokens.json"))
    p_serve.add_argument("--chat-seed", default="33x1-civil-vma")

    p_client = sub.add_parser("client")
    p_client.add_argument("--host", default="127.0.0.1")
    p_client.add_argument("--port", type=int, default=9333)
    p_client.add_argument("--token", required=True)
    p_client.add_argument("--chat-seed", default="33x1-civil-vma")
    p_client.add_argument("command")

    args = parser.parse_args()

    if args.cmd == "audit":
        recycler = ALURecycler()
        for i in range(args.passes):
            report = run_audit(args.dir, recycler=recycler, workers=args.workers)
            print(f"Pasada {i+1}: alu_executed={report.alu_executed} alu_saved={report.alu_saved}")
        save_report(report, args.out)
        print(f"Informe: {args.out}")
        return 0

    if args.cmd == "verify":
        print("OK" if verify_report(args.informe) else "FAIL")
        return 0

    if args.cmd == "token":
        store = TokenStore()
        if args.out.exists():
            store = TokenStore.from_dict(json.loads(args.out.read_text()))
        tok = store.add(args.role, args.ttl)
        args.out.write_text(json.dumps({"tokens": store.to_dict()}, indent=2), encoding="utf-8")
        print(f"Token: {tok}")
        return 0

    if args.cmd == "revoke":
        store = TokenStore.from_dict(json.loads(args.tokens.read_text()))
        print("Revocado" if store.revoke(args.token) else "No encontrado")
        args.tokens.write_text(json.dumps({"tokens": store.to_dict()}, indent=2), encoding="utf-8")
        return 0

    if args.cmd == "serve":
        store = TokenStore()
        if args.tokens.exists():
            store = TokenStore.from_dict(json.loads(args.tokens.read_text()))
        serve(args.host, args.port, args.dir, args.workers, store, args.chat_seed)
        return 0

    if args.cmd == "client":
        client(args.host, args.port, args.token, args.command, args.chat_seed)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
