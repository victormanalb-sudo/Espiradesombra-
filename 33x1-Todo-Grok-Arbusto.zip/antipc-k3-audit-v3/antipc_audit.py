"""
AntiPC-K3-Audit v3
Auditoría de integridad con K3 + servidor con control de acceso por token.
Uso civil · VMA / 33×1

Autor del marco: Víctor Manzanares Alberola
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import json
import secrets
import socket
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

# ── Núcleo K3 ─────────────────────────────────────────────────────────────────

OFFSETS = (5, 7, 9, 11, 13, 17, 19, 23)
MAGICO = 0x9E3779B1
FINAL_MUL_A = 0x85EBCA6B
FINAL_MUL_B = 0xC2B2AE35


def _rotl32(value: int, positions: int) -> int:
    positions &= 31
    if positions == 0:
        return value & 0xFFFFFFFF
    value &= 0xFFFFFFFF
    return ((value << positions) | (value >> (32 - positions))) & 0xFFFFFFFF


def _ejecutar_compresion_k3(estado: list[int], valor_bloque: int, n: int) -> None:
    b = valor_bloque & 0xFFFFFFFF
    x = (estado[0] ^ (b & estado[1 % n])) & 0xFFFFFFFF
    for j in range(2, n):
        x ^= _rotl32(estado[j], OFFSETS[j % 8])
    x ^= _rotl32(estado[1 % n], OFFSETS[4])
    x = (x + _rotl32(estado[0], OFFSETS[5])) & 0xFFFFFFFF
    x ^= (b * MAGICO) & 0xFFFFFFFF
    x ^= b
    x = (x + _rotl32(b, OFFSETS[6])) & 0xFFFFFFFF
    x ^= _rotl32(b, OFFSETS[7])
    x ^= _rotl32(x, OFFSETS[2])
    x = (x * MAGICO) & 0xFFFFFFFF
    x ^= (x >> 15)
    estado_anterior_0 = estado[0]
    estado[0] = x & 0xFFFFFFFF
    temp_prev = estado_anterior_0
    for i in range(1, n):
        temp_actual = estado[i]
        estado[i] = (_rotl32(estado[i], OFFSETS[0] + i) ^ temp_prev) & 0xFFFFFFFF
        temp_prev = temp_actual
        if i == n - 1:
            estado[i] ^= b
            estado[i] &= 0xFFFFFFFF


def _extraer_hash_final(registros: list[int], n: int) -> int:
    acumulador = registros[0]
    for i in range(1, n):
        acumulador ^= _rotl32(registros[i], 5 + i)
        acumulador &= 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    acumulador = (acumulador * FINAL_MUL_A) & 0xFFFFFFFF
    acumulador ^= acumulador >> 13
    acumulador = (acumulador * FINAL_MUL_B) & 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    return acumulador & 0xFFFFFFFF


def k3_hash_buffer(data: bytes, seed: int = 0x1F2E3D4C) -> int:
    n = 4
    registros = [(seed ^ (i * MAGICO)) & 0xFFFFFFFF for i in range(n)]
    ancho = 4
    i = 0
    buffer_parcial = bytearray(4)
    bytes_en_buffer = 0
    while i < len(data):
        while bytes_en_buffer < ancho and i < len(data):
            buffer_parcial[bytes_en_buffer] = data[i]
            bytes_en_buffer += 1
            i += 1
        if bytes_en_buffer == ancho:
            bloque = 0
            for b in range(ancho):
                bloque = (bloque << 8) | buffer_parcial[b]
            _ejecutar_compresion_k3(registros, bloque, n)
            bytes_en_buffer = 0
    if bytes_en_buffer > 0:
        bloque = 0
        for b in range(ancho):
            byte = buffer_parcial[b] if b < bytes_en_buffer else 0
            bloque = (bloque << 8) | byte
        _ejecutar_compresion_k3(registros, bloque, n)
    return _extraer_hash_final(registros, n)


# ── Control de acceso ─────────────────────────────────────────────────────────

@dataclass
class TokenStore:
    """Tokens válidos. En producción se cargarían de un fichero seguro."""
    tokens: dict[str, str] = field(default_factory=dict)  # token -> role

    def add(self, role: str = "auditor") -> str:
        token = secrets.token_hex(16)
        self.tokens[token] = role
        return token

    def check(self, token: str, required_role: str | None = None) -> bool:
        if token not in self.tokens:
            return False
        if required_role and self.tokens[token] != required_role:
            return False
        return True

    def role_of(self, token: str) -> str | None:
        return self.tokens.get(token)


# ── Caché y telemetría ────────────────────────────────────────────────────────

class KnowledgeCache:
    def __init__(self) -> None:
        self._store: dict[str, dict] = {}
        self.hits = 0
        self.misses = 0
        self._lock = threading.Lock()

    def get(self, key: str) -> dict | None:
        with self._lock:
            if key in self._store:
                self.hits += 1
                return self._store[key]
            self.misses += 1
            return None

    def put(self, key: str, value: dict) -> None:
        with self._lock:
            self._store[key] = value


@dataclass
class Telemetry:
    events: list[dict] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def log(self, event: str, **kwargs: Any) -> None:
        with self._lock:
            self.events.append({"t": time.time(), "event": event, **kwargs})

    def export_json(self, path: Path) -> None:
        path.write_text(json.dumps(self.events, indent=2), encoding="utf-8")

    def export_csv(self, path: Path) -> None:
        if not self.events:
            return
        keys = sorted({k for e in self.events for k in e})
        with path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(self.events)


# ── Auditoría ─────────────────────────────────────────────────────────────────

@dataclass
class FileEntry:
    path: str
    size: int
    k3: str
    sha256: str
    cached: bool = False


@dataclass
class AuditReport:
    version: str = "3.0.0"
    tool: str = "AntiPC-K3-Audit"
    author: str = "Víctor Manzanares Alberola (VMA) · 33×1"
    timestamp: str = ""
    root: str = ""
    files_scanned: int = 0
    files_hashed: int = 0
    knowledge_hits: int = 0
    knowledge_misses: int = 0
    duplicate_groups: int = 0
    bytes_recoverable: int = 0
    elapsed_s: float = 0.0
    workers: int = 1
    requester: str = ""
    entries: list[dict] = field(default_factory=list)
    groups: list[dict] = field(default_factory=list)
    manifesto_sha256: str = ""


def scan_directory(root: Path, max_files: int | None = None) -> list[Path]:
    files: list[Path] = []
    for p in root.rglob("*"):
        if p.is_file() and not p.name.startswith("."):
            files.append(p)
            if max_files and len(files) >= max_files:
                break
    return files


def _hash_one(p: Path, root: Path, cache: KnowledgeCache, telem: Telemetry) -> FileEntry | None:
    try:
        data = p.read_bytes()
        size = len(data)
        quick = hashlib.sha256(data).hexdigest()[:16]
        key = f"{size}:{quick}"
        cached = cache.get(key)
        if cached:
            telem.log("cache_hit", path=str(p))
            return FileEntry(
                path=str(p.relative_to(root)),
                size=size,
                k3=cached["k3"],
                sha256=cached["sha256"],
                cached=True,
            )
        k3 = k3_hash_buffer(data)
        sha = hashlib.sha256(data).hexdigest()
        entry = FileEntry(
            path=str(p.relative_to(root)),
            size=size,
            k3=f"{k3:08X}",
            sha256=sha,
        )
        cache.put(key, {"k3": entry.k3, "sha256": sha})
        telem.log("hash", path=str(p), k3=entry.k3)
        return entry
    except OSError:
        telem.log("error", path=str(p))
        return None


def run_audit(
    root: Path,
    max_files: int | None = None,
    workers: int = 4,
    cache: KnowledgeCache | None = None,
    requester: str = "",
) -> tuple[AuditReport, Telemetry]:
    if cache is None:
        cache = KnowledgeCache()
    telem = Telemetry()
    t0 = time.perf_counter()
    paths = scan_directory(root, max_files)
    telem.log("scan_start", count=len(paths), workers=workers, requester=requester)

    entries: list[FileEntry] = []
    if workers <= 1:
        for p in paths:
            e = _hash_one(p, root, cache, telem)
            if e:
                entries.append(e)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(_hash_one, p, root, cache, telem) for p in paths]
            for fut in as_completed(futs):
                e = fut.result()
                if e:
                    entries.append(e)

    groups_map: dict[str, list[str]] = defaultdict(list)
    size_map: dict[str, int] = {}
    for e in entries:
        key = f"{e.size}:{e.k3}"
        groups_map[key].append(e.path)
        size_map[key] = e.size

    groups = []
    bytes_recoverable = 0
    for key, plist in groups_map.items():
        if len(plist) > 1:
            sz = size_map[key]
            groups.append({"key": key, "count": len(plist), "total_bytes": sz * len(plist), "paths": plist})
            bytes_recoverable += sz * (len(plist) - 1)

    elapsed = time.perf_counter() - t0
    report = AuditReport(
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        root=str(root.resolve()),
        files_scanned=len(paths),
        files_hashed=len(entries),
        knowledge_hits=cache.hits,
        knowledge_misses=cache.misses,
        duplicate_groups=len(groups),
        bytes_recoverable=bytes_recoverable,
        elapsed_s=round(elapsed, 4),
        workers=workers,
        requester=requester,
        entries=[asdict(e) for e in entries],
        groups=groups,
    )
    payload = json.dumps(
        {k: v for k, v in asdict(report).items() if k != "manifesto_sha256"},
        sort_keys=True, ensure_ascii=False,
    ).encode("utf-8")
    report.manifesto_sha256 = hashlib.sha256(payload).hexdigest()
    telem.log("done", elapsed=elapsed, hits=cache.hits)
    return report, telem


def save_report(report: AuditReport, out: Path) -> None:
    out.write_text(json.dumps(asdict(report), indent=2, ensure_ascii=False), encoding="utf-8")


def verify_report(path: Path) -> bool:
    data = json.loads(path.read_text(encoding="utf-8"))
    claimed = data.pop("manifesto_sha256", None)
    if not claimed:
        print("ERROR: sin manifiesto")
        return False
    payload = json.dumps(data, sort_keys=True, ensure_ascii=False).encode("utf-8")
    actual = hashlib.sha256(payload).hexdigest()
    ok = actual == claimed
    print(f"Manifiesto {'OK' if ok else 'FAIL'}")
    return ok


# ── Servidor con control de acceso ────────────────────────────────────────────

def _recv_line(conn: socket.socket) -> str:
    data = b""
    while b"\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data += chunk
    return data.decode("utf-8", errors="ignore").strip()


def serve(host: str, port: int, root: Path, workers: int, tokens: TokenStore, telem: Telemetry) -> None:
    cache = KnowledgeCache()
    print(f"AntiPC-K3-Audit v3 servidor en {host}:{port}")
    print(f"Root: {root}")
    print(f"Tokens activos: {len(tokens.tokens)}")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(5)
        while True:
            conn, addr = s.accept()
            threading.Thread(target=_handle_client, args=(conn, addr, root, workers, tokens, cache, telem), daemon=True).start()


def _handle_client(
    conn: socket.socket,
    addr: tuple,
    root: Path,
    workers: int,
    tokens: TokenStore,
    cache: KnowledgeCache,
    telem: Telemetry,
) -> None:
    with conn:
        try:
            first = _recv_line(conn)
            if not first.startswith("AUTH "):
                telem.log("auth_fail", addr=str(addr), reason="missing_auth")
                conn.sendall(b"DENIED missing_auth\n")
                return
            token = first[5:].strip()
            if not tokens.check(token):
                telem.log("auth_fail", addr=str(addr), reason="invalid_token")
                conn.sendall(b"DENIED invalid_token\n")
                return
            role = tokens.role_of(token) or "unknown"
            telem.log("auth_ok", addr=str(addr), role=role)
            conn.sendall(b"OK\n")

            cmd = _recv_line(conn)
            if cmd == "AUDIT":
                if role not in ("auditor", "admin"):
                    telem.log("denied", addr=str(addr), cmd="AUDIT", role=role)
                    conn.sendall(b"DENIED role\n")
                    return
                report, _ = run_audit(root, workers=workers, cache=cache, requester=f"{addr[0]}:{role}")
                payload = json.dumps(asdict(report)).encode("utf-8")
                conn.sendall(payload + b"\n")
                telem.log("audit_done", addr=str(addr), files=report.files_hashed)
            elif cmd == "STATS":
                stats = {"hits": cache.hits, "misses": cache.misses, "role": role}
                conn.sendall(json.dumps(stats).encode() + b"\n")
            else:
                conn.sendall(b"UNKNOWN\n")
        except Exception as e:
            telem.log("error", addr=str(addr), error=str(e))


def client(host: str, port: int, token: str, cmd: str) -> None:
    with socket.create_connection((host, port), timeout=30) as s:
        s.sendall(f"AUTH {token}\n".encode())
        resp = _recv_line(s)
        if resp != "OK":
            print(f"Acceso denegado: {resp}")
            return
        s.sendall((cmd + "\n").encode())
        data = b""
        while True:
            chunk = s.recv(65536)
            if not chunk:
                break
            data += chunk
            if b"\n" in data:
                break
        print(data.decode("utf-8", errors="ignore").strip())


def main() -> int:
    parser = argparse.ArgumentParser(description="AntiPC-K3-Audit v3 · VMA / 33×1 · uso civil")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_audit = sub.add_parser("audit", help="Auditar directorio local")
    p_audit.add_argument("--dir", required=True, type=Path)
    p_audit.add_argument("--out", required=True, type=Path)
    p_audit.add_argument("--workers", type=int, default=4)
    p_audit.add_argument("--max-files", type=int)
    p_audit.add_argument("--telemetry", type=Path)

    p_verify = sub.add_parser("verify", help="Verificar manifiesto")
    p_verify.add_argument("informe", type=Path)

    p_token = sub.add_parser("token", help="Generar token de acceso")
    p_token.add_argument("--role", choices=["auditor", "admin"], default="auditor")
    p_token.add_argument("--out", type=Path, default=Path("tokens.json"))

    p_serve = sub.add_parser("serve", help="Servidor con control de acceso")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=9333)
    p_serve.add_argument("--dir", required=True, type=Path)
    p_serve.add_argument("--workers", type=int, default=4)
    p_serve.add_argument("--tokens", type=Path, default=Path("tokens.json"))
    p_serve.add_argument("--telemetry", type=Path, default=Path("telemetry_server.json"))

    p_client = sub.add_parser("client", help="Cliente autenticado")
    p_client.add_argument("--host", default="127.0.0.1")
    p_client.add_argument("--port", type=int, default=9333)
    p_client.add_argument("--token", required=True)
    p_client.add_argument("command", choices=["AUDIT", "STATS"])

    args = parser.parse_args()

    if args.cmd == "audit":
        if not args.dir.is_dir():
            print("ERROR: directorio no existe", file=sys.stderr)
            return 1
        report, telem = run_audit(args.dir, args.max_files, args.workers)
        save_report(report, args.out)
        if args.telemetry:
            telem.export_json(args.telemetry)
        print(f"Informe: {args.out}")
        print(f"  ficheros: {report.files_hashed}  hits: {report.knowledge_hits}")
        return 0

    if args.cmd == "verify":
        return 0 if verify_report(args.informe) else 2

    if args.cmd == "token":
        store = TokenStore()
        if args.out.exists():
            data = json.loads(args.out.read_text())
            store.tokens = data.get("tokens", {})
        tok = store.add(args.role)
        args.out.write_text(json.dumps({"tokens": store.tokens}, indent=2), encoding="utf-8")
        print(f"Token ({args.role}): {tok}")
        print(f"Guardado en {args.out}")
        return 0

    if args.cmd == "serve":
        store = TokenStore()
        if args.tokens.exists():
            data = json.loads(args.tokens.read_text())
            store.tokens = data.get("tokens", {})
        if not store.tokens:
            print("ERROR: no hay tokens. Genera uno con: python antipc_audit.py token")
            return 1
        telem = Telemetry()
        try:
            serve(args.host, args.port, args.dir, args.workers, store, telem)
        except KeyboardInterrupt:
            telem.export_json(args.telemetry)
        return 0

    if args.cmd == "client":
        client(args.host, args.port, args.token, args.command)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
