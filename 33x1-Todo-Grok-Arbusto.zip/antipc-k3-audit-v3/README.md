# AntiPC-K3-Audit v3

Auditoría de integridad con K3 y **control de acceso** en modo cliente-servidor.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Qué añade v3

- **Autenticación por token** obligatoria antes de cualquier comando.
- Roles: `auditor` (puede pedir AUDIT y STATS) y `admin`.
- Registro de intentos (auth_ok, auth_fail, denied, audit_done) en telemetría.
- El servidor rechaza conexiones sin token válido o con rol insuficiente.
- Campo `requester` en el informe (IP + rol).
- Referencias de autoría mantenidas.

## Uso

```bash
# Generar un token
python antipc_audit.py token --role auditor --out tokens.json

# Servidor
python antipc_audit.py serve --dir /datos --tokens tokens.json --port 9333

# Cliente (debe presentar token)
python antipc_audit.py client --token EL_TOKEN AUDIT
python antipc_audit.py client --token EL_TOKEN STATS

# Auditoría local (sin red)
python antipc_audit.py audit --dir /ruta --out informe.json

# Verificar manifiesto
python antipc_audit.py verify informe.json
```

## Control de acceso

| Acción | Sin token | Token auditor | Token admin |
|--------|-----------|---------------|-------------|
| Conectar | DENIED | OK | OK |
| AUDIT | DENIED | OK | OK |
| STATS | DENIED | OK | OK |

Los tokens se guardan en `tokens.json` (formato simple). En un entorno real se debería proteger el fichero y rotar tokens.

## Qué no es

- No es el stack AntiPC completo (no tiene Grafcet, UDP fabric, gemelos, etc.).
- El servidor es TCP plano (sin TLS). Para uso real hay que ponerlo detrás de un túnel o añadir TLS.
- No implementa listas de revocación ni caducidad de tokens (se puede añadir después).

**VMA — AntiPC-K3-Audit v3 / 33×1** · Uso civil.
