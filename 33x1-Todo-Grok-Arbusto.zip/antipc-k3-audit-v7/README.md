# AntiPC-K3-Audit v7

Auditoría K3 + reciclaje de ALU + **núcleo geométrico** portado de `encriptacionGeometrica/k3_core.c` + rotación de semilla.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Qué se ha implementado (criterio)

1. **GeoMotor** — port directo del stream de `k3_cifrar_bloque` (evolución de L/v + XOR con constante áurea). Reversible.
2. **SeedRing** — lista circular de semillas. Comando `ROTATE` (solo admin) avanza a la siguiente.
3. Comando `SEND <texto>` — el cliente cifra con la semilla actual y el servidor descifra y confirma.
4. El audit **no rota solo**. Informa; el operador decide si rota.
5. Reciclaje de ALU y manifiesto se mantienen.

## Entrada manual de semillas (fuera de canal)

```bash
# Pedir por teclado (no viaja por red)
python antipc_audit.py manual-seed --seeds seeds.json

# O pasar directamente (sigue siendo local)
python antipc_audit.py manual-seed --seeds seeds.json --seed "mi-semilla-a-mano"
```

Después copia `seeds.json` al otro extremo por un medio físico o fuera de banda (papel, USB, etc.).  
El chat no se usa para transmitir las semillas.

```bash
# Semillas
python antipc_audit.py seeds --add semilla-uno --add semilla-dos --out seeds.json

# Token admin
python antipc_audit.py token --role admin --out tokens.json

# Servidor
python antipc_audit.py serve --dir /datos --tokens tokens.json --seeds seeds.json

# Cliente: enviar mensaje cifrado con semilla actual
python antipc_audit.py client --token TOKEN --seeds seeds.json "SEND hola futuro"

# Cliente admin: rotar a la siguiente semilla
python antipc_audit.py client --token TOKEN_ADMIN --seeds seeds.json ROTATE
```

## Límites

- El canal TCP sigue siendo plano. El cifrado geométrico protege el contenido del mensaje **si** la semilla no se intercepta.
- No es un sistema de paso de contraseñas de alta seguridad. Es una capa civil auditable que usa el núcleo geométrico del repo.
- Si el audit detecta algo raro, el operador puede ejecutar `ROTATE` manualmente. No hay cambio automático silencioso.

**VMA — AntiPC-K3-Audit v7 / 33×1** · Uso civil.
