# AntiPC-K3-Audit v2

Paquete de auditoría de integridad con K3, ampliado con piezas útiles del AntiPC industrial.

**Uso civil · 33×1**

## Novedades respecto a v1

- **Workers** (ThreadPoolExecutor) para paralelizar el hash.
- **Caché K(N)**: segunda pasada sobre los mismos datos reutiliza resultados (knowledge hits).
- **Telemetría** CSV/JSON de eventos.
- **Servidor TCP simple** + cliente: permite pedir una auditoría remota sobre un directorio del servidor.
- Manifiesto SHA256 verificable del informe.

Sigue siendo **autónomo** (solo Python 3.10+, sin DLL ni dependencias).

## Uso

```bash
# Auditoría local
python antipc_audit.py audit --dir /ruta --out informe.json --workers 4 --telemetry telem.json

# Verificar manifiesto
python antipc_audit.py verify informe.json

# Servidor (en una máquina)
python antipc_audit.py serve --dir /datos --port 9333 --workers 4

# Cliente (desde otra)
python antipc_audit.py client --host IP_SERVIDOR AUDIT
python antipc_audit.py client --host IP_SERVIDOR STATS
```

## Qué NO es

- No es el stack AntiPC completo (no tiene Grafcet, UDP fabric, MMO, gemelos, etc.).
- El “servidor” es un TCP sencillo de un solo cliente a la vez, pensado para demostración y uso controlado.
- No sustituye una solución de producción con autenticación, TLS o alta disponibilidad.

## Origen

Núcleo K3 extraído del port oficial de `k3hash.c`.  
Ideas de workers, caché y telemetría tomadas del `IndustrialRuntime` y demo industrial del repo `espiradesombra/claude`.

**VMA — AntiPC-K3-Audit v2 / 33×1** · Uso civil.
