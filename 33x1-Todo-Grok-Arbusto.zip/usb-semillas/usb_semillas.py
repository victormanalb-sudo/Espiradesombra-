"""
Generador de pares de USB para semillas — AntiPC-K3-Audit
Uso civil · VMA / 33×1

Genera lotes de semillas emparejadas, listas para copiar a dos USBs
con la misma etiqueta. Borra el material de trabajo al terminar.
"""

from __future__ import annotations

import argparse
import json
import os
import secrets
import shutil
import time
from pathlib import Path


def generar_semilla() -> str:
    return secrets.token_hex(16)


def generar_lote(cantidad: int, semillas_por_usb: int, out_dir: Path) -> list[dict]:
    """Genera `cantidad` pares. Cada par tiene dos carpetas idénticas."""
    out_dir.mkdir(parents=True, exist_ok=True)
    registros = []

    for i in range(1, cantidad + 1):
        etiqueta = f"USB-{i:04d}"
        semillas = [generar_semilla() for _ in range(semillas_por_usb)]
        payload = {
            "etiqueta": etiqueta,
            "creado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "seeds": semillas,
            "index": 0,
        }

        # Dos copias idénticas (A y B)
        for lado in ("A", "B"):
            carpeta = out_dir / f"{etiqueta}-{lado}"
            carpeta.mkdir(exist_ok=True)
            (carpeta / "seeds.json").write_text(
                json.dumps(payload, indent=2), encoding="utf-8"
            )
            (carpeta / "LEEME.txt").write_text(
                f"Etiqueta: {etiqueta}\n"
                f"Lado: {lado}\n"
                f"Semillas: {semillas_por_usb}\n"
                f"Uso: copiar seeds.json al sistema AntiPC-K3-Audit.\n"
                f"Después de copiar, borrar esta carpeta del ordenador.\n"
                f"Civil · VMA / 33×1\n",
                encoding="utf-8",
            )

        registros.append({
            "etiqueta": etiqueta,
            "semillas": semillas_por_usb,
            "estado": "generado",
        })

    # Registro maestro (se borra después si se pide)
    (out_dir / "_registro.json").write_text(
        json.dumps(registros, indent=2), encoding="utf-8"
    )
    return registros


def etiquetas_imprimibles(out_dir: Path, registros: list[dict]) -> Path:
    """Genera un fichero de texto con etiquetas para escribir a mano o imprimir."""
    lineas = ["ETIQUETAS PARA USBs (escribir a mano o imprimir)", "=" * 40, ""]
    for r in registros:
        lineas.append(f"[ {r['etiqueta']} ]")
        lineas.append("")
    path = out_dir / "ETIQUETAS.txt"
    path.write_text("\n".join(lineas), encoding="utf-8")
    return path


def borrar_material(out_dir: Path) -> None:
    """Borra todo el material de trabajo. Irreversible."""
    if out_dir.exists():
        shutil.rmtree(out_dir)
        print(f"Borrado: {out_dir}")


def confirmar(etiqueta: str, log_path: Path) -> None:
    """Registra que alguien confirmó por llamada la recepción de un USB."""
    entrada = {
        "etiqueta": etiqueta,
        "confirmado": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "nota": "recibido, lo introduzco",
    }
    log = []
    if log_path.exists():
        log = json.loads(log_path.read_text(encoding="utf-8"))
    log.append(entrada)
    log_path.write_text(json.dumps(log, indent=2), encoding="utf-8")
    print(f"Confirmado: {etiqueta}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Generador de pares de USB para semillas · civil"
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_gen = sub.add_parser("generar", help="Generar lote de pares")
    p_gen.add_argument("--cantidad", type=int, required=True, help="número de pares")
    p_gen.add_argument("--semillas", type=int, default=5, help="semillas por USB")
    p_gen.add_argument("--out", type=Path, default=Path("lote_usb"))

    p_borrar = sub.add_parser("borrar", help="Borrar material de trabajo")
    p_borrar.add_argument("--dir", type=Path, required=True)

    p_conf = sub.add_parser("confirmar", help="Registrar confirmación por llamada")
    p_conf.add_argument("etiqueta", help="ej. USB-0005")
    p_conf.add_argument("--log", type=Path, default=Path("confirmaciones.json"))

    args = parser.parse_args()

    if args.cmd == "generar":
        registros = generar_lote(args.cantidad, args.semillas, args.out)
        etiquetas_imprimibles(args.out, registros)
        print(f"Generados {len(registros)} pares en {args.out}")
        print(f"Etiquetas: {args.out / 'ETIQUETAS.txt'}")
        print("Copia cada par (A y B) a dos USBs con la misma etiqueta.")
        print("Después ejecuta: python usb_semillas.py borrar --dir", args.out)
        return 0

    if args.cmd == "borrar":
        borrar_material(args.dir)
        return 0

    if args.cmd == "confirmar":
        confirmar(args.etiqueta, args.log)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
