# Generador de pares de USB para semillas

Herramienta civil para preparar lotes de semillas emparejadas, listas para copiar a USBs físicos.  
**Uso civil · VMA / 33×1**

## Flujo

1. Generar un lote de pares.
2. Escribir o imprimir las etiquetas a mano.
3. Copiar cada par (A y B) a dos USBs con la misma etiqueta.
4. Borrar el material del ordenador.
5. Cuando alguien confirma por llamada (“USB-0005 recibido, lo introduzco”), registrarlo.

## Uso

```bash
# Generar 20 pares, 5 semillas cada uno
python usb_semillas.py generar --cantidad 20 --semillas 5 --out lote_usb

# Ver etiquetas
cat lote_usb/ETIQUETAS.txt

# Después de copiar a los USBs, borrar todo el material de trabajo
python usb_semillas.py borrar --dir lote_usb

# Registrar confirmación por llamada
python usb_semillas.py confirmar USB-0005
```

## Qué contiene cada USB

- `seeds.json` — compatible con AntiPC-K3-Audit (`manual-seed` o carga directa).
- `LEEME.txt` — instrucciones mínimas.

## Notas

- Las dos copias de un par son idénticas.
- El borrado es irreversible (`shutil.rmtree`).
- El registro de confirmaciones es local y auditable.
- No transmite semillas por red.

**Civil · VMA / 33×1**
