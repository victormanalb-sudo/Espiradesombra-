"""
AntiPC-K3-Audit v7
+ Núcleo geométrico portado de encriptacionGeometrica/k3_core.c
+ Chat con mensajes cifrados geométricamente
+ Rotación de semilla autenticada
Uso civil · Víctor Manzanares Alberola (VMA) · 33×1
"""

from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import secrets
import socket
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

# ── Núcleo K3 (hash) ──────────────────────────────────────────────────────────

OFFSETS = (5, 7, 9, 11, 13, 17, 19, 23)
MAGICO = 0x9E3779B1
FINAL_MUL_A = 0x85EBCA6B
FINAL_MUL_B = 0xC2B2AE35


def _rotl32(value: int, positions: int) -> int:
    positions &= 31
    if positions == 0:
        return value & 0xFFFFFFFF
    value &= 0xFFFFFFFF
    return ((value << positions) | (value >> (32 - positions))) & 0xFFFFFFFF


def _ejecutar_compresion_k3(estado: list[int], valor_bloque: int, n: int) -> None:
    b = valor_bloque & 0xFFFFFFFF
    x = (estado[0] ^ (b & estado[1 % n])) & 0xFFFFFFFF
    for j in range(2, n):
        x ^= _rotl32(estado[j], OFFSETS[j % 8])
    x ^= _rotl32(estado[1 % n], OFFSETS[4])
    x = (x + _rotl32(estado[0], OFFSETS[5])) & 0xFFFFFFFF
    x ^= (b * MAGICO) & 0xFFFFFFFF
    x ^= b
    x = (x + _rotl32(b, OFFSETS[6])) & 0xFFFFFFFF
    x ^= _rotl32(b, OFFSETS[7])
    x ^= _rotl32(x, OFFSETS[2])
    x = (x * MAGICO) & 0xFFFFFFFF
    x ^= (x >> 15)
    estado_anterior_0 = estado[0]
    estado[0] = x & 0xFFFFFFFF
    temp_prev = estado_anterior_0
    for i in range(1, n):
        temp_actual = estado[i]
        estado[i] = (_rotl32(estado[i], OFFSETS[0] + i) ^ temp_prev) & 0xFFFFFFFF
        temp_prev = temp_actual
        if i == n - 1:
            estado[i] ^= b
            estado[i] &= 0xFFFFFFFF


def _extraer_hash_final(registros: list[int], n: int) -> int:
    acumulador = registros[0]
    for i in range(1, n):
        acumulador ^= _rotl32(registros[i], 5 + i)
        acumulador &= 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    acumulador = (acumulador * FINAL_MUL_A) & 0xFFFFFFFF
    acumulador ^= acumulador >> 13
    acumulador = (acumulador * FINAL_MUL_B) & 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    return acumulador & 0xFFFFFFFF


def k3_hash_buffer(data: bytes, seed: int = 0x1F2E3D4C) -> int:
    n = 4
    registros = [(seed ^ (i * MAGICO)) & 0xFFFFFFFF for i in range(n)]
    ancho = 4
    i = 0
    buffer_parcial = bytearray(4)
    bytes_en_buffer = 0
    while i < len(data):
        while bytes_en_buffer < ancho and i < len(data):
            buffer_parcial[bytes_en_buffer] = data[i]
            bytes_en_buffer += 1
            i += 1
        if bytes_en_buffer == ancho:
            bloque = 0
            for b in range(ancho):
                bloque = (bloque << 8) | buffer_parcial[b]
            _ejecutar_compresion_k3(registros, bloque, n)
            bytes_en_buffer = 0
    if bytes_en_buffer > 0:
        bloque = 0
        for b in range(ancho):
            byte = buffer_parcial[b] if b < bytes_en_buffer else 0
            bloque = (bloque << 8) | byte
        _ejecutar_compresion_k3(registros, bloque, n)
    return _extraer_hash_final(registros, n)


# ── Núcleo geométrico (port de k3_core.c) ─────────────────────────────────────

class GeoMotor:
    """Port civil de k3_cifrar_bloque. Stream XOR reversible."""
    def __init__(self, seed: str) -> None:
        h = k3_hash_buffer(seed.encode("utf-8"))
        self.v = (h | 1) & 0xFFFFFFFFFFFFFFFF  # impar
        self.L = (h ^ 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF

    def process(self, data: bytes) -> bytes:
        out = bytearray(data)
        v = self.v
        L = self.L
        for i in range(len(out)):
            L = (L + (v + 1)) & 0xFFFFFFFFFFFFFFFF
            v = (v + 2) & 0xFFFFFFFFFFFFFFFF
            if (5 * L) <= (2 * v + 1):
                L = (L + (v * 2)) & 0xFFFFFFFFFFFFFFFF
            stream = ((L ^ v) * 0x9E3779B97F4A7C15) & 0xFFFFFFFFFFFFFFFF
            out[i] ^= stream & 0xFF
        return bytes(out)


def geo_encrypt(seed: str, plaintext: str) -> str:
    motor = GeoMotor(seed)
    ct = motor.process(plaintext.encode("utf-8"))
    return ct.hex()


def geo_decrypt(seed: str, ciphertext_hex: str) -> str:
    motor = GeoMotor(seed)
    ct = bytes.fromhex(ciphertext_hex)
    pt = motor.process(ct)
    return pt.decode("utf-8", errors="replace")


# ── ALU Recycler ──────────────────────────────────────────────────────────────

class ALURecycler:
    def __init__(self) -> None:
        self._store: dict[str, dict] = {}
        self.alu_executed = 0
        self.alu_saved = 0
        self._lock = threading.Lock()

    def get_or_compute(self, data: bytes, path: str) -> dict:
        sig = f"{k3_hash_buffer(data):08X}"
        with self._lock:
            if sig in self._store:
                self.alu_saved += 1
                return {**self._store[sig], "cached": True}
            result = {
                "path": path,
                "size": len(data),
                "k3": sig,
                "sha256": hashlib.sha256(data).hexdigest(),
                "cached": False,
            }
            self._store[sig] = result
            self.alu_executed += 1
            return result


# ── Tokens ────────────────────────────────────────────────────────────────────

@dataclass
class TokenInfo:
    role: str
    created: float
    expires: float
    revoked: bool = False


class TokenStore:
    def __init__(self) -> None:
        self.tokens: dict[str, TokenInfo] = {}

    def add(self, role: str = "auditor", ttl_seconds: int = 3600) -> str:
        token = secrets.token_hex(16)
        now = time.time()
        self.tokens[token] = TokenInfo(role=role, created=now, expires=now + ttl_seconds)
        return token

    def check(self, token: str) -> bool:
        info = self.tokens.get(token)
        return bool(info and not info.revoked and time.time() <= info.expires)

    def role_of(self, token: str) -> str | None:
        return self.tokens[token].role if self.check(token) else None

    def revoke(self, token: str) -> bool:
        if token in self.tokens:
            self.tokens[token].revoked = True
            return True
        return False

    def to_dict(self) -> dict:
        return {t: asdict(i) for t, i in self.tokens.items()}

    @classmethod
    def from_dict(cls, data: dict) -> "TokenStore":
        s = cls()
        for t, i in data.get("tokens", {}).items():
            s.tokens[t] = TokenInfo(**i)
        return s


# ── Semillas de rotación ──────────────────────────────────────────────────────

class SeedRing:
    """Lista circular de semillas. Rotar avanza el índice."""
    def __init__(self, seeds: list[str]) -> None:
        if not seeds:
            seeds = ["semilla-inicial-civil"]
        self.seeds = seeds
        self.index = 0
        self._lock = threading.Lock()

    def current(self) -> str:
        with self._lock:
            return self.seeds[self.index % len(self.seeds)]

    def rotate(self) -> str:
        with self._lock:
            self.index = (self.index + 1) % len(self.seeds)
            return self.seeds[self.index]

    def to_dict(self) -> dict:
        return {"seeds": self.seeds, "index": self.index}

    @classmethod
    def from_dict(cls, data: dict) -> "SeedRing":
        r = cls(data.get("seeds", ["semilla-inicial-civil"]))
        r.index = data.get("index", 0)
        return r


# ── Auditoría ─────────────────────────────────────────────────────────────────

@dataclass
class AuditReport:
    version: str = "8.0.0"
    tool: str = "AntiPC-K3-Audit"
    author: str = "Víctor Manzanares Alberola (VMA) · 33×1"
    timestamp: str = ""
    root: str = ""
    files_scanned: int = 0
    files_hashed: int = 0
    alu_executed: int = 0
    alu_saved: int = 0
    duplicate_groups: int = 0
    bytes_recoverable: int = 0
    elapsed_s: float = 0.0
    anomaly: bool = False
    anomaly_reason: str = ""
    seed_fingerprint: str = ""
    rotations: list[dict] = field(default_factory=list)
    entries: list[dict] = field(default_factory=list)
    groups: list[dict] = field(default_factory=list)
    manifesto_sha256: str = ""


def scan_directory(root: Path) -> list[Path]:
    return [p for p in root.rglob("*") if p.is_file() and not p.name.startswith(".")]


def seed_fingerprint(seed: str) -> str:
    """Huella pública corta de la semilla (K3). Se puede comparar a mano."""
    return f"{k3_hash_buffer(seed.encode('utf-8')):08X}"


def run_audit(root: Path, recycler: ALURecycler | None = None, workers: int = 4,
              previous_report: Path | None = None, seed: str = "",
              rotations: list[dict] | None = None) -> AuditReport:
    if recycler is None:
        recycler = ALURecycler()
    t0 = time.perf_counter()
    paths = scan_directory(root)

    def task(p: Path):
        try:
            return recycler.get_or_compute(p.read_bytes(), str(p.relative_to(root)))
        except OSError:
            return None

    entries = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for r in pool.map(task, paths):
            if r:
                entries.append(r)

    groups_map = defaultdict(list)
    size_map = {}
    for e in entries:
        key = f"{e['size']}:{e['k3']}"
        groups_map[key].append(e["path"])
        size_map[key] = e["size"]
    groups = []
    recoverable = 0
    for key, plist in groups_map.items():
        if len(plist) > 1:
            sz = size_map[key]
            groups.append({"key": key, "count": len(plist), "paths": plist})
            recoverable += sz * (len(plist) - 1)

    elapsed = time.perf_counter() - t0
    anomaly = False
    reason = ""
    if previous_report and previous_report.exists():
        if not verify_report(previous_report):
            anomaly = True
            reason = "manifiesto_anterior_no_cuadra"
    if recycler.alu_executed > 0 and recycler.alu_saved == 0 and len(entries) > 1:
        # segunda pasada esperada debería ahorrar; si no, marcar
        pass  # se deja al operador; no forzamos aquí

    report = AuditReport(
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        root=str(root.resolve()),
        files_scanned=len(paths),
        files_hashed=len(entries),
        alu_executed=recycler.alu_executed,
        alu_saved=recycler.alu_saved,
        duplicate_groups=len(groups),
        bytes_recoverable=recoverable,
        elapsed_s=round(elapsed, 4),
        anomaly=anomaly,
        anomaly_reason=reason,
        seed_fingerprint=seed_fingerprint(seed) if seed else "",
        rotations=rotations or [],
        entries=entries,
        groups=groups,
    )
    payload = json.dumps({k: v for k, v in asdict(report).items() if k != "manifesto_sha256"},
                         sort_keys=True, ensure_ascii=False).encode()
    report.manifesto_sha256 = hashlib.sha256(payload).hexdigest()
    return report


def save_report(report: AuditReport, out: Path) -> None:
    out.write_text(json.dumps(asdict(report), indent=2, ensure_ascii=False), encoding="utf-8")


def verify_report(path: Path) -> bool:
    data = json.loads(path.read_text(encoding="utf-8"))
    claimed = data.pop("manifesto_sha256", None)
    if not claimed:
        return False
    payload = json.dumps(data, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(payload).hexdigest() == claimed


# ── Servidor ──────────────────────────────────────────────────────────────────

def _recv_line(conn: socket.socket) -> str:
    data = b""
    while b"\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data += chunk
    return data.decode("utf-8", errors="ignore").strip()


def serve(host: str, port: int, root: Path, tokens: TokenStore, seeds: SeedRing) -> None:
    recycler = ALURecycler()
    rotations: list[dict] = []
    print(f"AntiPC-K3-Audit v8 en {host}:{port}")
    print(f"Semilla actual: {seeds.current()[:12]}... fp={seed_fingerprint(seeds.current())}")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(5)
        while True:
            conn, addr = s.accept()
            threading.Thread(target=_handle, args=(conn, addr, root, tokens, seeds, recycler, rotations), daemon=True).start()


def _handle(conn, addr, root, tokens, seeds, recycler, rotations):
    with conn:
        first = _recv_line(conn)
        if not first.startswith("AUTH ") or not tokens.check(first[5:].strip()):
            conn.sendall(b"DENIED\n")
            return
        role = tokens.role_of(first[5:].strip()) or "?"
        conn.sendall(b"OK\n")
        while True:
            line = _recv_line(conn)
            if not line or line == "QUIT":
                break
            if line == "AUDIT":
                report = run_audit(root, recycler=recycler, seed=seeds.current(), rotations=rotations)
                conn.sendall(json.dumps(asdict(report)).encode() + b"\n")
            elif line == "STATS":
                stats = {
                    "alu_executed": recycler.alu_executed,
                    "alu_saved": recycler.alu_saved,
                    "seed_index": seeds.index,
                    "seed_fp": seed_fingerprint(seeds.current()),
                    "rotations": len(rotations),
                    "role": role,
                }
                conn.sendall(json.dumps(stats).encode() + b"\n")
            elif line == "SEEDFP":
                conn.sendall(f"FP {seed_fingerprint(seeds.current())}\n".encode())
            elif line == "ROTATE":
                if role != "admin":
                    conn.sendall(b"DENIED\n")
                    continue
                new_seed = seeds.rotate()
                rotations.append({
                    "t": time.time(),
                    "index": seeds.index,
                    "fp": seed_fingerprint(new_seed),
                    "by": str(addr),
                })
                conn.sendall(f"ROTATED {seeds.index} FP {seed_fingerprint(new_seed)}\n".encode())
            elif line.startswith("SEND "):
                try:
                    hexdata = line[5:]
                    plain = geo_decrypt(seeds.current(), hexdata)
                    conn.sendall(f"RECV {plain}\n".encode())
                except Exception:
                    conn.sendall(b"BAD\n")
            else:
                conn.sendall(b"UNKNOWN\n")


def client_pipe(host: str, port: int, token: str, seeds: SeedRing) -> None:
    """Modo pipe: lee líneas de stdin, las envía cifradas, imprime respuestas en stdout.
    Para conectar periféricos o scripts locales al canal autenticado.
    """
    import sys
    with socket.create_connection((host, port), timeout=30) as s:
        s.sendall(f"AUTH {token}\n".encode())
        if _recv_line(s) != "OK":
            print("DENIED", file=sys.stderr)
            return
        print("PIPE OK", file=sys.stderr)
        for line in sys.stdin:
            line = line.strip()
            if not line or line == "QUIT":
                break
            if line.startswith("SEND "):
                plain = line[5:]
                hexdata = geo_encrypt(seeds.current(), plain)
                s.sendall(f"SEND {hexdata}\n".encode())
            else:
                # trata la línea como mensaje a enviar
                hexdata = geo_encrypt(seeds.current(), line)
                s.sendall(f"SEND {hexdata}\n".encode())
            resp = _recv_line(s)
            print(resp, flush=True)
        s.sendall(b"QUIT\n")
    with socket.create_connection((host, port), timeout=30) as s:
        s.sendall(f"AUTH {token}\n".encode())
        if _recv_line(s) != "OK":
            print("DENIED")
            return
        if cmd.startswith("SEND "):
            plain = cmd[5:]
            hexdata = geo_encrypt(seeds.current(), plain)
            s.sendall(f"SEND {hexdata}\n".encode())
        elif cmd == "SEEDFP":
            s.sendall(b"SEEDFP\n")
        else:
            s.sendall((cmd + "\n").encode())
        print(_recv_line(s))


def main() -> int:
    parser = argparse.ArgumentParser(description="AntiPC-K3-Audit v7 · VMA / 33×1 · uso civil")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_audit = sub.add_parser("audit")
    p_audit.add_argument("--dir", required=True, type=Path)
    p_audit.add_argument("--out", required=True, type=Path)
    p_audit.add_argument("--passes", type=int, default=1)

    p_verify = sub.add_parser("verify")
    p_verify.add_argument("informe", type=Path)

    p_token = sub.add_parser("token")
    p_token.add_argument("--role", choices=["auditor", "admin"], default="auditor")
    p_token.add_argument("--ttl", type=int, default=3600)
    p_token.add_argument("--out", type=Path, default=Path("tokens.json"))

    p_seeds = sub.add_parser("seeds")
    p_seeds.add_argument("--add", action="append", default=[])
    p_seeds.add_argument("--out", type=Path, default=Path("seeds.json"))

    p_serve = sub.add_parser("serve")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=9333)
    p_serve.add_argument("--dir", required=True, type=Path)
    p_serve.add_argument("--tokens", type=Path, default=Path("tokens.json"))
    p_serve.add_argument("--seeds", type=Path, default=Path("seeds.json"))

    p_manual = sub.add_parser("manual-seed", help="Añadir semilla a mano (fuera de canal)")
    p_manual.add_argument("--seeds", type=Path, default=Path("seeds.json"))
    p_manual.add_argument("--seed", help="semilla (si se omite, se pide por teclado)")

    p_client = sub.add_parser("client")
    p_client.add_argument("--host", default="127.0.0.1")
    p_client.add_argument("--port", type=int, default=9333)
    p_client.add_argument("--token", required=True)
    p_client.add_argument("--seeds", type=Path, default=Path("seeds.json"))
    p_client.add_argument("command")

    p_pipe = sub.add_parser("pipe", help="Modo pipe: stdin → chat cifrado → stdout")
    p_pipe.add_argument("--host", default="127.0.0.1")
    p_pipe.add_argument("--port", type=int, default=9333)
    p_pipe.add_argument("--token", required=True)
    p_pipe.add_argument("--seeds", type=Path, default=Path("seeds.json"))

    args = parser.parse_args()

    if args.cmd == "manual-seed":
        ring = SeedRing(["semilla-inicial-civil"])
        if args.seeds.exists():
            ring = SeedRing.from_dict(json.loads(args.seeds.read_text(encoding="utf-8")))
        if args.seed:
            new = args.seed.strip()
        else:
            print("Introduce la semilla a mano (no se envía por red):")
            new = input("> ").strip()
        if not new:
            print("Vacía, no se añade")
            return 1
        if new in ring.seeds:
            print("Ya existe")
        else:
            ring.seeds.append(new)
            print(f"Añadida. Total: {len(ring.seeds)}")
        args.seeds.write_text(json.dumps(ring.to_dict(), indent=2), encoding="utf-8")
        print(f"Guardado en {args.seeds}")
        print("Recuerda copiar el fichero seeds.json por un medio fuera de banda al otro extremo.")
        return 0

    if args.cmd == "audit":
        recycler = ALURecycler()
        for i in range(args.passes):
            report = run_audit(args.dir, recycler=recycler)
            print(f"Pasada {i+1}: executed={report.alu_executed} saved={report.alu_saved}")
        save_report(report, args.out)
        return 0

    if args.cmd == "verify":
        print("OK" if verify_report(args.informe) else "FAIL")
        return 0

    if args.cmd == "token":
        store = TokenStore()
        if args.out.exists():
            store = TokenStore.from_dict(json.loads(args.out.read_text()))
        tok = store.add(args.role, args.ttl)
        args.out.write_text(json.dumps({"tokens": store.to_dict()}, indent=2), encoding="utf-8")
        print(tok)
        return 0

    if args.cmd == "seeds":
        ring = SeedRing([])
        if args.out.exists():
            ring = SeedRing.from_dict(json.loads(args.out.read_text()))
        for s in args.add:
            if s not in ring.seeds:
                ring.seeds.append(s)
        args.out.write_text(json.dumps(ring.to_dict(), indent=2), encoding="utf-8")
        print(f"Semillas: {len(ring.seeds)} índice={ring.index}")
        return 0

    if args.cmd == "serve":
        tokens = TokenStore()
        if args.tokens.exists():
            tokens = TokenStore.from_dict(json.loads(args.tokens.read_text()))
        seeds = SeedRing(["semilla-inicial-civil"])
        if args.seeds.exists():
            seeds = SeedRing.from_dict(json.loads(args.seeds.read_text()))
        serve(args.host, args.port, args.dir, tokens, seeds)
        return 0

    if args.cmd == "pipe":
        seeds = SeedRing(["semilla-inicial-civil"])
        if args.seeds.exists():
            seeds = SeedRing.from_dict(json.loads(args.seeds.read_text()))
        client_pipe(args.host, args.port, args.token, seeds)
        return 0

    if args.cmd == "client":
        seeds = SeedRing(["semilla-inicial-civil"])
        if args.seeds.exists():
            seeds = SeedRing.from_dict(json.loads(args.seeds.read_text()))
        client(args.host, args.port, args.token, args.command, seeds)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
