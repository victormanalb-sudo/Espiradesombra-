# AntiPC-K3-Audit v8

Auditoría K3 + reciclaje de ALU + núcleo geométrico + entrada manual de semillas + **huella de semilla y registro de rotaciones**.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Qué he elegido meter en v8

1. **Huella pública de la semilla** (`SEEDFP`)  
   Comando que devuelve los 8 hex del K3 de la semilla actual.  
   Se puede anotar a mano y comparar con el otro extremo sin enviar la semilla.

2. **Registro de rotaciones**  
   Cada `ROTATE` queda anotado (tiempo, índice, huella, origen).  
   El siguiente `AUDIT` incluye la lista en el informe.

3. **Marca de anomalía explícita**  
   Si se pasa un informe anterior y su manifiesto no cuadra, el nuevo informe marca `anomaly=true` y la razón.  
   No rota solo; el operador decide.

## Modo pipe (periféricos / scripts)

```bash
# Conecta stdin/stdout al canal autenticado
echo "hola desde periferico" | python antipc_audit.py pipe --token TOKEN --seeds seeds.json
```

Cualquier línea que llegue por stdin se cifra y se envía.  
La respuesta del servidor sale por stdout.  
Útil para scripts o dispositivos locales que hablen por tuberías.

```bash
# Ver huella de la semilla actual (para anotar a mano)
python antipc_audit.py client --token TOKEN --seeds seeds.json SEEDFP

# Tras un ROTATE, el AUDIT incluye el historial
python antipc_audit.py client --token TOKEN AUDIT
```

## Entrada manual de semillas (sigue igual)

```bash
python antipc_audit.py manual-seed --seeds seeds.json
```

Después copia `seeds.json` fuera de banda.  
La huella que muestra el servidor te permite comprobar que ambos lados tienen la misma.

**VMA — AntiPC-K3-Audit v8 / 33×1** · Uso civil.