# AntiPC-K3-Audit v4

Auditoría de integridad K3 + control de acceso endurecido + chat autenticado.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Novedades de v4

- **Tokens con caducidad** (`--ttl` en segundos).
- **Lista de revocación** (`revoke`).
- **Chat autenticado**: mensajes firmados con HMAC-SHA256. El servidor verifica la firma antes de aceptar.
- Registro de eventos de autenticación y chat en telemetría.
- Referencias de autoría mantenidas.

## Uso

```bash
# Token con vida de 1 hora
python antipc_audit.py token --role auditor --ttl 3600 --out tokens.json

# Revocar
python antipc_audit.py revoke EL_TOKEN --tokens tokens.json

# Servidor
python antipc_audit.py serve --dir /datos --tokens tokens.json --chat-key mi-clave-civil

# Cliente auditoría
python antipc_audit.py client --token EL_TOKEN AUDIT

# Cliente chat (mensaje firmado)
python antipc_audit.py client --token EL_TOKEN --chat-key mi-clave-civil "CHAT hola desde el cliente"
```

## Seguridad (marco civil)

| Control | Implementado |
|---------|--------------|
| Autenticación previa | Sí (token) |
| Caducidad | Sí |
| Revocación | Sí |
| Integridad de mensajes de chat | Sí (HMAC) |
| TLS / cifrado de canal | No (añadir túnel o TLS externo) |
| Perfect forward secrecy | No |

**No es un sistema de grado militar.** Es una capa civil auditable que demuestra control de acceso, caducidad, revocación e integridad de mensajes. Para un entorno real se debe proteger el transporte (TLS o VPN) y la gestión de claves.

**VMA — AntiPC-K3-Audit v4 / 33×1** · Uso civil.
