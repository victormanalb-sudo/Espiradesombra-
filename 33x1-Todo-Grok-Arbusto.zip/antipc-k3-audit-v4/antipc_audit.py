"""
AntiPC-K3-Audit v4
Auditoría K3 + control de acceso con caducidad y revocación + chat autenticado.
Uso civil · Víctor Manzanares Alberola (VMA) · 33×1

Modo endurecido: tokens con TTL, lista de revocación, mensajes firmados con HMAC.
No es un sistema militar; es una capa civil auditable.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import hmac
import json
import secrets
import socket
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

# ── Núcleo K3 (igual que v3) ──────────────────────────────────────────────────

OFFSETS = (5, 7, 9, 11, 13, 17, 19, 23)
MAGICO = 0x9E3779B1
FINAL_MUL_A = 0x85EBCA6B
FINAL_MUL_B = 0xC2B2AE35


def _rotl32(value: int, positions: int) -> int:
    positions &= 31
    if positions == 0:
        return value & 0xFFFFFFFF
    value &= 0xFFFFFFFF
    return ((value << positions) | (value >> (32 - positions))) & 0xFFFFFFFF


def _ejecutar_compresion_k3(estado: list[int], valor_bloque: int, n: int) -> None:
    b = valor_bloque & 0xFFFFFFFF
    x = (estado[0] ^ (b & estado[1 % n])) & 0xFFFFFFFF
    for j in range(2, n):
        x ^= _rotl32(estado[j], OFFSETS[j % 8])
    x ^= _rotl32(estado[1 % n], OFFSETS[4])
    x = (x + _rotl32(estado[0], OFFSETS[5])) & 0xFFFFFFFF
    x ^= (b * MAGICO) & 0xFFFFFFFF
    x ^= b
    x = (x + _rotl32(b, OFFSETS[6])) & 0xFFFFFFFF
    x ^= _rotl32(b, OFFSETS[7])
    x ^= _rotl32(x, OFFSETS[2])
    x = (x * MAGICO) & 0xFFFFFFFF
    x ^= (x >> 15)
    estado_anterior_0 = estado[0]
    estado[0] = x & 0xFFFFFFFF
    temp_prev = estado_anterior_0
    for i in range(1, n):
        temp_actual = estado[i]
        estado[i] = (_rotl32(estado[i], OFFSETS[0] + i) ^ temp_prev) & 0xFFFFFFFF
        temp_prev = temp_actual
        if i == n - 1:
            estado[i] ^= b
            estado[i] &= 0xFFFFFFFF


def _extraer_hash_final(registros: list[int], n: int) -> int:
    acumulador = registros[0]
    for i in range(1, n):
        acumulador ^= _rotl32(registros[i], 5 + i)
        acumulador &= 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    acumulador = (acumulador * FINAL_MUL_A) & 0xFFFFFFFF
    acumulador ^= acumulador >> 13
    acumulador = (acumulador * FINAL_MUL_B) & 0xFFFFFFFF
    acumulador ^= acumulador >> 16
    return acumulador & 0xFFFFFFFF


def k3_hash_buffer(data: bytes, seed: int = 0x1F2E3D4C) -> int:
    n = 4
    registros = [(seed ^ (i * MAGICO)) & 0xFFFFFFFF for i in range(n)]
    ancho = 4
    i = 0
    buffer_parcial = bytearray(4)
    bytes_en_buffer = 0
    while i < len(data):
        while bytes_en_buffer < ancho and i < len(data):
            buffer_parcial[bytes_en_buffer] = data[i]
            bytes_en_buffer += 1
            i += 1
        if bytes_en_buffer == ancho:
            bloque = 0
            for b in range(ancho):
                bloque = (bloque << 8) | buffer_parcial[b]
            _ejecutar_compresion_k3(registros, bloque, n)
            bytes_en_buffer = 0
    if bytes_en_buffer > 0:
        bloque = 0
        for b in range(ancho):
            byte = buffer_parcial[b] if b < bytes_en_buffer else 0
            bloque = (bloque << 8) | byte
        _ejecutar_compresion_k3(registros, bloque, n)
    return _extraer_hash_final(registros, n)


# ── Tokens con caducidad y revocación ─────────────────────────────────────────

@dataclass
class TokenInfo:
    role: str
    created: float
    expires: float
    revoked: bool = False


class TokenStore:
    def __init__(self) -> None:
        self.tokens: dict[str, TokenInfo] = {}

    def add(self, role: str = "auditor", ttl_seconds: int = 3600) -> str:
        token = secrets.token_hex(16)
        now = time.time()
        self.tokens[token] = TokenInfo(role=role, created=now, expires=now + ttl_seconds)
        return token

    def check(self, token: str, required_role: str | None = None) -> bool:
        info = self.tokens.get(token)
        if not info or info.revoked:
            return False
        if time.time() > info.expires:
            return False
        if required_role and info.role != required_role:
            return False
        return True

    def role_of(self, token: str) -> str | None:
        info = self.tokens.get(token)
        return info.role if info and not info.revoked and time.time() <= info.expires else None

    def revoke(self, token: str) -> bool:
        if token in self.tokens:
            self.tokens[token].revoked = True
            return True
        return False

    def to_dict(self) -> dict:
        return {
            tok: {
                "role": info.role,
                "created": info.created,
                "expires": info.expires,
                "revoked": info.revoked,
            }
            for tok, info in self.tokens.items()
        }

    @classmethod
    def from_dict(cls, data: dict) -> "TokenStore":
        store = cls()
        for tok, info in data.get("tokens", {}).items():
            store.tokens[tok] = TokenInfo(**info)
        return store


# ── HMAC para mensajes de chat ────────────────────────────────────────────────

def sign_message(key: bytes, msg: str) -> str:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).hexdigest()


def verify_message(key: bytes, msg: str, signature: str) -> bool:
    expected = sign_message(key, msg)
    return hmac.compare_digest(expected, signature)


# ── Caché, telemetría, auditoría (igual base que v3) ──────────────────────────

class KnowledgeCache:
    def __init__(self) -> None:
        self._store: dict[str, dict] = {}
        self.hits = 0
        self.misses = 0
        self._lock = threading.Lock()

    def get(self, key: str) -> dict | None:
        with self._lock:
            if key in self._store:
                self.hits += 1
                return self._store[key]
            self.misses += 1
            return None

    def put(self, key: str, value: dict) -> None:
        with self._lock:
            self._store[key] = value


@dataclass
class Telemetry:
    events: list[dict] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def log(self, event: str, **kwargs: Any) -> None:
        with self._lock:
            self.events.append({"t": time.time(), "event": event, **kwargs})

    def export_json(self, path: Path) -> None:
        path.write_text(json.dumps(self.events, indent=2), encoding="utf-8")


@dataclass
class FileEntry:
    path: str
    size: int
    k3: str
    sha256: str
    cached: bool = False


@dataclass
class AuditReport:
    version: str = "4.0.0"
    tool: str = "AntiPC-K3-Audit"
    author: str = "Víctor Manzanares Alberola (VMA) · 33×1"
    timestamp: str = ""
    root: str = ""
    files_scanned: int = 0
    files_hashed: int = 0
    knowledge_hits: int = 0
    knowledge_misses: int = 0
    duplicate_groups: int = 0
    bytes_recoverable: int = 0
    elapsed_s: float = 0.0
    workers: int = 1
    requester: str = ""
    entries: list[dict] = field(default_factory=list)
    groups: list[dict] = field(default_factory=list)
    manifesto_sha256: str = ""


def scan_directory(root: Path, max_files: int | None = None) -> list[Path]:
    files: list[Path] = []
    for p in root.rglob("*"):
        if p.is_file() and not p.name.startswith("."):
            files.append(p)
            if max_files and len(files) >= max_files:
                break
    return files


def _hash_one(p: Path, root: Path, cache: KnowledgeCache, telem: Telemetry) -> FileEntry | None:
    try:
        data = p.read_bytes()
        size = len(data)
        quick = hashlib.sha256(data).hexdigest()[:16]
        key = f"{size}:{quick}"
        cached = cache.get(key)
        if cached:
            return FileEntry(path=str(p.relative_to(root)), size=size, k3=cached["k3"], sha256=cached["sha256"], cached=True)
        k3 = k3_hash_buffer(data)
        sha = hashlib.sha256(data).hexdigest()
        entry = FileEntry(path=str(p.relative_to(root)), size=size, k3=f"{k3:08X}", sha256=sha)
        cache.put(key, {"k3": entry.k3, "sha256": sha})
        return entry
    except OSError:
        return None


def run_audit(root: Path, max_files: int | None = None, workers: int = 4,
              cache: KnowledgeCache | None = None, requester: str = "") -> tuple[AuditReport, Telemetry]:
    if cache is None:
        cache = KnowledgeCache()
    telem = Telemetry()
    t0 = time.perf_counter()
    paths = scan_directory(root, max_files)
    entries: list[FileEntry] = []
    if workers <= 1:
        for p in paths:
            e = _hash_one(p, root, cache, telem)
            if e:
                entries.append(e)
    else:
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futs = [pool.submit(_hash_one, p, root, cache, telem) for p in paths]
            for fut in as_completed(futs):
                e = fut.result()
                if e:
                    entries.append(e)

    groups_map: dict[str, list[str]] = defaultdict(list)
    size_map: dict[str, int] = {}
    for e in entries:
        key = f"{e.size}:{e.k3}"
        groups_map[key].append(e.path)
        size_map[key] = e.size
    groups = []
    bytes_recoverable = 0
    for key, plist in groups_map.items():
        if len(plist) > 1:
            sz = size_map[key]
            groups.append({"key": key, "count": len(plist), "total_bytes": sz * len(plist), "paths": plist})
            bytes_recoverable += sz * (len(plist) - 1)

    elapsed = time.perf_counter() - t0
    report = AuditReport(
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        root=str(root.resolve()),
        files_scanned=len(paths),
        files_hashed=len(entries),
        knowledge_hits=cache.hits,
        knowledge_misses=cache.misses,
        duplicate_groups=len(groups),
        bytes_recoverable=bytes_recoverable,
        elapsed_s=round(elapsed, 4),
        workers=workers,
        requester=requester,
        entries=[asdict(e) for e in entries],
        groups=groups,
    )
    payload = json.dumps({k: v for k, v in asdict(report).items() if k != "manifesto_sha256"},
                         sort_keys=True, ensure_ascii=False).encode("utf-8")
    report.manifesto_sha256 = hashlib.sha256(payload).hexdigest()
    return report, telem


def save_report(report: AuditReport, out: Path) -> None:
    out.write_text(json.dumps(asdict(report), indent=2, ensure_ascii=False), encoding="utf-8")


def verify_report(path: Path) -> bool:
    data = json.loads(path.read_text(encoding="utf-8"))
    claimed = data.pop("manifesto_sha256", None)
    if not claimed:
        return False
    payload = json.dumps(data, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest() == claimed


# ── Servidor ──────────────────────────────────────────────────────────────────

def _recv_line(conn: socket.socket) -> str:
    data = b""
    while b"\n" not in data:
        chunk = conn.recv(4096)
        if not chunk:
            break
        data += chunk
    return data.decode("utf-8", errors="ignore").strip()


def serve(host: str, port: int, root: Path, workers: int, tokens: TokenStore, chat_key: bytes, telem: Telemetry) -> None:
    cache = KnowledgeCache()
    chat_log: list[str] = []
    print(f"AntiPC-K3-Audit v4 servidor en {host}:{port}")
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, port))
        s.listen(5)
        while True:
            conn, addr = s.accept()
            threading.Thread(
                target=_handle_client,
                args=(conn, addr, root, workers, tokens, cache, chat_key, chat_log, telem),
                daemon=True,
            ).start()


def _handle_client(conn, addr, root, workers, tokens, cache, chat_key, chat_log, telem):
    with conn:
        try:
            first = _recv_line(conn)
            if not first.startswith("AUTH "):
                telem.log("auth_fail", addr=str(addr), reason="missing")
                conn.sendall(b"DENIED\n")
                return
            token = first[5:].strip()
            if not tokens.check(token):
                telem.log("auth_fail", addr=str(addr), reason="invalid_or_expired")
                conn.sendall(b"DENIED\n")
                return
            role = tokens.role_of(token) or "unknown"
            telem.log("auth_ok", addr=str(addr), role=role)
            conn.sendall(b"OK\n")

            while True:
                line = _recv_line(conn)
                if not line:
                    break
                if line == "AUDIT":
                    if role not in ("auditor", "admin"):
                        conn.sendall(b"DENIED role\n")
                        continue
                    report, _ = run_audit(root, workers=workers, cache=cache, requester=f"{addr[0]}:{role}")
                    conn.sendall(json.dumps(asdict(report)).encode() + b"\n")
                elif line == "STATS":
                    stats = {"hits": cache.hits, "misses": cache.misses, "role": role, "chat_msgs": len(chat_log)}
                    conn.sendall(json.dumps(stats).encode() + b"\n")
                elif line.startswith("CHAT "):
                    # CHAT <mensaje>|<hmac>
                    try:
                        body, sig = line[5:].rsplit("|", 1)
                    except ValueError:
                        conn.sendall(b"BAD_FORMAT\n")
                        continue
                    if not verify_message(chat_key, body, sig):
                        telem.log("chat_bad_sig", addr=str(addr))
                        conn.sendall(b"BAD_SIG\n")
                        continue
                    chat_log.append(f"{addr[0]}:{role}: {body}")
                    telem.log("chat", addr=str(addr), msg=body[:80])
                    # eco firmado
                    reply = f"ECHO {body}"
                    reply_sig = sign_message(chat_key, reply)
                    conn.sendall(f"{reply}|{reply_sig}\n".encode())
                elif line == "CHATLOG":
                    if role != "admin":
                        conn.sendall(b"DENIED\n")
                        continue
                    conn.sendall(json.dumps(chat_log).encode() + b"\n")
                elif line == "QUIT":
                    break
                else:
                    conn.sendall(b"UNKNOWN\n")
        except Exception as e:
            telem.log("error", addr=str(addr), error=str(e))


def client(host: str, port: int, token: str, cmd: str, chat_key: bytes | None = None) -> None:
    with socket.create_connection((host, port), timeout=30) as s:
        s.sendall(f"AUTH {token}\n".encode())
        if _recv_line(s) != "OK":
            print("Acceso denegado")
            return
        if cmd.startswith("CHAT ") and chat_key:
            body = cmd[5:]
            sig = sign_message(chat_key, body)
            s.sendall(f"CHAT {body}|{sig}\n".encode())
        else:
            s.sendall((cmd + "\n").encode())
        print(_recv_line(s))


def main() -> int:
    parser = argparse.ArgumentParser(description="AntiPC-K3-Audit v4 · VMA / 33×1 · uso civil")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_audit = sub.add_parser("audit")
    p_audit.add_argument("--dir", required=True, type=Path)
    p_audit.add_argument("--out", required=True, type=Path)
    p_audit.add_argument("--workers", type=int, default=4)

    p_verify = sub.add_parser("verify")
    p_verify.add_argument("informe", type=Path)

    p_token = sub.add_parser("token")
    p_token.add_argument("--role", choices=["auditor", "admin"], default="auditor")
    p_token.add_argument("--ttl", type=int, default=3600, help="segundos de vida")
    p_token.add_argument("--out", type=Path, default=Path("tokens.json"))

    p_revoke = sub.add_parser("revoke")
    p_revoke.add_argument("token")
    p_revoke.add_argument("--tokens", type=Path, default=Path("tokens.json"))

    p_serve = sub.add_parser("serve")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=9333)
    p_serve.add_argument("--dir", required=True, type=Path)
    p_serve.add_argument("--workers", type=int, default=4)
    p_serve.add_argument("--tokens", type=Path, default=Path("tokens.json"))
    p_serve.add_argument("--chat-key", default="cambia-esta-clave-civil", help="clave HMAC del chat")

    p_client = sub.add_parser("client")
    p_client.add_argument("--host", default="127.0.0.1")
    p_client.add_argument("--port", type=int, default=9333)
    p_client.add_argument("--token", required=True)
    p_client.add_argument("--chat-key", default="cambia-esta-clave-civil")
    p_client.add_argument("command")

    args = parser.parse_args()

    if args.cmd == "audit":
        report, _ = run_audit(args.dir, workers=args.workers)
        save_report(report, args.out)
        print(f"Informe: {args.out}")
        return 0

    if args.cmd == "verify":
        ok = verify_report(args.informe)
        print("OK" if ok else "FAIL")
        return 0 if ok else 2

    if args.cmd == "token":
        store = TokenStore()
        if args.out.exists():
            store = TokenStore.from_dict(json.loads(args.out.read_text()))
        tok = store.add(args.role, args.ttl)
        args.out.write_text(json.dumps({"tokens": store.to_dict()}, indent=2), encoding="utf-8")
        print(f"Token ({args.role}, ttl={args.ttl}s): {tok}")
        return 0

    if args.cmd == "revoke":
        store = TokenStore.from_dict(json.loads(args.tokens.read_text()))
        if store.revoke(args.token):
            args.tokens.write_text(json.dumps({"tokens": store.to_dict()}, indent=2), encoding="utf-8")
            print("Revocado")
        else:
            print("Token no encontrado")
        return 0

    if args.cmd == "serve":
        store = TokenStore()
        if args.tokens.exists():
            store = TokenStore.from_dict(json.loads(args.tokens.read_text()))
        if not store.tokens:
            print("Genera tokens primero")
            return 1
        chat_key = args.chat_key.encode("utf-8")
        telem = Telemetry()
        serve(args.host, args.port, args.dir, args.workers, store, chat_key, telem)
        return 0

    if args.cmd == "client":
        key = args.chat_key.encode("utf-8")
        client(args.host, args.port, args.token, args.command, key)
        return 0

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
