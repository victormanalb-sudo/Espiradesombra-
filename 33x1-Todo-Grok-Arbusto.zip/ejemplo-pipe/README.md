# Ejemplo de uso: pipe + USBs + llamada

Este ejemplo muestra cómo un programa local (dispositivo, sensor o micro codificado)  
usa el modo `pipe` del AntiPC-K3-Audit v8.

**Importante:** las semillas no viajan por este canal.  
Llegan en un USB y se confirman por llamada.

## Flujo completo de seguridad de la semilla

1. En un ordenador seguro generas los pares:
   ```bash
   python usb_semillas.py generar --cantidad 10 --semillas 5 --out lote_usb
   ```
2. Escribes o imprimes las etiquetas a mano.
3. Copias cada par (A y B) a dos USBs físicos con la misma etiqueta.
4. Borras el material del ordenador:
   ```bash
   python usb_semillas.py borrar --dir lote_usb
   ```
5. Entregas los USBs por un medio físico.
6. Cuando el otro extremo recibe el USB llama y dice:  
   **“USB-0005 recibido, lo introduzco”**
7. Tú registras la confirmación:
   ```bash
   python usb_semillas.py confirmar USB-0005
   ```
8. Solo entonces el otro extremo introduce el `seeds.json` del USB en su sistema.

## Uso del pipe (después de tener la semilla)

En el lado servidor:
```bash
python antipc_audit.py serve --dir /datos --tokens tokens.json --seeds seeds.json
```

En el lado del dispositivo (este ejemplo):
```bash
python dispositivo_ejemplo.py | python antipc_audit.py pipe --token TU_TOKEN --seeds seeds.json
```

El programa de ejemplo envía tres líneas (simulando lecturas de sensor o muestras codificadas de micro).  
El modo `pipe` las cifra con la semilla actual y las envía.  
La respuesta del servidor aparece en stdout.

## Qué demuestra

- El canal autenticado puede transportar datos de un programa local.
- La semilla que protege esos datos llegó fuera de banda (USB + llamada).
- Nada de lo sensible viajó por la red antes de la confirmación humana.

**Civil · VMA / 33×1**
