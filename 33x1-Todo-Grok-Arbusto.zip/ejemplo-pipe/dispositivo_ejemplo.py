#!/usr/bin/env python3
"""
Ejemplo de uso del modo pipe de AntiPC-K3-Audit v8.
Simula un dispositivo local (por ejemplo un micro codificado)
que envía líneas por stdin al canal autenticado.

Requisito previo: las semillas deben haber llegado por USB
y haberse confirmado por llamada.
"""

import sys
import time

def main():
    print("=== Ejemplo de dispositivo local (pipe) ===", file=sys.stderr)
    print("Enviando 3 mensajes de prueba...", file=sys.stderr)

    mensajes = [
        "sensor: temperatura 23.4",
        "micro: muestra-codificada-001",
        "micro: muestra-codificada-002",
    ]

    for msg in mensajes:
        print(msg, flush=True)
        time.sleep(0.3)

    print("QUIT", flush=True)
    print("=== Fin del ejemplo ===", file=sys.stderr)

if __name__ == "__main__":
    main()
