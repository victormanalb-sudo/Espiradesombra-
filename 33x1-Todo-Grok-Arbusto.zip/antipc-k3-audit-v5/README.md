# AntiPC-K3-Audit v5

Auditoría de integridad K3 + control de acceso endurecido + chat autenticado.  
**Uso civil · Víctor Manzanares Alberola (VMA) · 33×1**

## Novedades de v5

- Incorpora el principio de **knowledge reuse** del ecosistema VMA:  
  *“Mover conocimiento, no recalcular ALU.”*  
  La caché K(N) ya existía; ahora el informe y el README lo nombran explícitamente.
- Nota de origen: material de referencia tomado de `victormanalb-sudo/Espiradesombra-` (explicación de AntiPC knowledge reuse) y del monorepo principal.
- Resto igual que v4: tokens con TTL, revocación, HMAC en chat, manifiesto SHA256.

## Uso

```bash
# Token con vida de 1 hora
python antipc_audit.py token --role auditor --ttl 3600 --out tokens.json

# Revocar
python antipc_audit.py revoke EL_TOKEN --tokens tokens.json

# Servidor
python antipc_audit.py serve --dir /datos --tokens tokens.json --chat-key mi-clave-civil

# Cliente auditoría
python antipc_audit.py client --token EL_TOKEN AUDIT

# Cliente chat (mensaje firmado)
python antipc_audit.py client --token EL_TOKEN --chat-key mi-clave-civil "CHAT hola desde el cliente"
```

## Knowledge reuse (principio VMA)

La segunda pasada sobre los mismos ficheros debe mostrar `knowledge_hits` > 0 y no recalcular el hash K3.  
Eso es el equivalente práctico de la ley que aparece en la gráfica 06 del repo de archivo: reutilizar el conocimiento en lugar de volver a ejecutar la ALU.

## Seguridad (marco civil)

| Control | Implementado |
|---------|--------------|
| Autenticación previa | Sí (token) |
| Caducidad | Sí |
| Revocación | Sí |
| Integridad de mensajes de chat | Sí (HMAC) |
| TLS / cifrado de canal | No (añadir túnel o TLS externo) |
| Perfect forward secrecy | No |

**No es un sistema de grado militar.** Es una capa civil auditable.  
Para un entorno real se debe proteger el transporte (TLS o VPN) y la gestión de claves.

**VMA — AntiPC-K3-Audit v5 / 33×1** · Uso civil.  
Referencia de archivo: `victormanalb-sudo/Espiradesombra-`