#!/usr/bin/env python3
"""
red.py — Modelo de red simplificado (swing equation agregada + gobernador)
y proceso de viento Ornstein-Uhlenbeck con ráfaga/calma programadas.

Convenio: todas las potencias en MW, S_base en MVA~MW, H en s, f en Hz.
Ecuación de oscilación (single-bus, frequency response model estándar
en estudios de inercia / RoCoF, p.ej. Anderson & Mirheydar / ENTSO-E):

    2*H_sys*S_base/f0 * df/dt = P_gov(t) + P_dev(t) + P_dist(t) - D*S_base*df/f0

Convenio de signos:
  P_dist(t) < 0  → pérdida de generación (déficit de potencia)
  P_dev(t)  > 0  → el dispositivo INYECTA potencia a la red (ayuda)
  P_dev(t)  < 0  → el dispositivo ABSORBE potencia (carga/acelera rotor)
  P_gov(t)  > 0  → el gobernador primario aumenta generación
"""
import numpy as np
from dataclasses import dataclass, field


@dataclass
class ParametrosRed:
    S_base: float = 2000.0      # MVA
    H_sys: float = 4.0          # s (inercia síncrona de la red, SIN el dispositivo)
    f0: float = 50.0            # Hz
    D: float = 0.05             # pu (amortiguamiento de carga)
    T_gov: float = 5.0          # s (constante de tiempo del gobernador)
    R_droop: float = 0.05       # pu (estatismo 5%)
    P_gov_max: float = 0.15     # fracción de S_base


@dataclass
class ParametrosViento:
    v_base: float = 11.4        # m/s
    sigma: float = 1.5          # m/s
    tau: float = 30.0           # s, constante de tiempo OU (típica turbulencia de viento)
    dv_rafaga: float = 3.5      # m/s
    t_rafaga: tuple = (45.0, 55.0)
    dv_calma: float = -5.0      # m/s
    t_calma: tuple = (65.0, 75.0)


def simular_viento(t, p: ParametrosViento, rng: np.random.Generator):
    """Proceso Ornstein-Uhlenbeck + eventos deterministas de ráfaga/calma."""
    dt = t[1] - t[0]
    n = len(t)
    v = np.empty(n)
    v[0] = p.v_base
    ruido = rng.normal(0.0, 1.0, n)
    for k in range(1, n):
        dv_ou = -(v[k - 1] - p.v_base) / p.tau * dt + p.sigma * np.sqrt(2 * dt / p.tau) * ruido[k]
        v[k] = v[k - 1] + dv_ou
    # eventos deterministas superpuestos (rampa suave con coseno)
    def rampa(t_arr, t0, t1, delta):
        out = np.zeros_like(t_arr)
        dur = t1 - t0
        for i, tt in enumerate(t_arr):
            if t0 <= tt <= t1:
                out[i] = delta * 0.5 * (1 - np.cos(np.pi * (tt - t0) / dur))
            elif tt > t1:
                out[i] = delta
        return out
    v = v + rampa(t, *p.t_rafaga, p.dv_rafaga) + rampa(t, *p.t_calma, p.dv_calma)
    return np.clip(v, 0.0, None)


def perturbacion(t, t_evento=30.0, dP=-100.0, rampa_s=0.3):
    """Escalón de potencia (pérdida de generación) con rampa corta realista."""
    out = np.zeros_like(t)
    for i, tt in enumerate(t):
        if tt < t_evento:
            out[i] = 0.0
        elif tt < t_evento + rampa_s:
            out[i] = dP * (tt - t_evento) / rampa_s
        else:
            out[i] = dP
    return out


def simular_red(t, p_dist, p_dev_func, red: ParametrosRed, estado_dev=None,
                 f_colapso=47.0):
    """
    Integra la ecuación de oscilación con Euler explícito.
    p_dev_func(k, t_k, df_pu, dfdt_pu, estado_dev) -> (P_dev_MW, estado_dev_actualizado)
    Devuelve dict con f(t), rocof(t), P_gov(t), P_dev(t).

    Si f cae por debajo de f_colapso, se considera que ha actuado la
    protección de la red (deslastre de carga automático, UFLS) y se
    detiene la integración: NO se modela aquí el deslastre en sí, solo se
    marca el colapso para no reportar frecuencias negativas sin sentido
    físico. Esto ocurre cuando la perturbación excede la reserva primaria
    disponible (P_gov_max) más la aportación del dispositivo.
    """
    dt = t[1] - t[0]
    n = len(t)
    f = np.full(n, red.f0)
    df = np.zeros(n)          # pu
    rocof = np.zeros(n)       # Hz/s
    P_gov = np.zeros(n)
    P_dev = np.zeros(n)
    P_gov_obj = 0.0
    colapso = False
    k_colapso = None

    for k in range(1, n):
        if colapso:
            f[k] = f[k - 1]
            df[k] = df[k - 1]
            rocof[k] = 0.0
            P_gov[k] = P_gov[k - 1]
            P_dev[k] = P_dev[k - 1]
            continue
        df_pu_prev = df[k - 1]
        # gobernador primario (droop) con retardo de primer orden hacia el objetivo
        P_gov_target = np.clip(-df_pu_prev / red.R_droop, -red.P_gov_max, red.P_gov_max) * red.S_base
        P_gov_obj += (P_gov_target - P_gov_obj) * dt / red.T_gov
        P_gov[k] = P_gov_obj

        dfdt_prev = rocof[k - 1]
        p_dev_val, estado_dev = p_dev_func(k, t[k], df_pu_prev, dfdt_prev, estado_dev)
        P_dev[k] = p_dev_val

        P_net = P_gov[k] + P_dev[k] + p_dist[k] - red.D * red.S_base * df_pu_prev
        ddf_pu = P_net / (2 * red.H_sys * red.S_base) * dt
        df[k] = df_pu_prev + ddf_pu
        f[k] = red.f0 * (1 + df[k])
        rocof[k] = (f[k] - f[k - 1]) / dt

        if f[k] < f_colapso:
            colapso = True
            k_colapso = k

    return {"t": t, "f": f, "rocof": rocof, "P_gov": P_gov, "P_dev": P_dev,
            "df_pu": df, "colapso": colapso, "k_colapso": k_colapso}


def metricas(res, f0=50.0, t_evento=30.0, umbral=49.9):
    t, f, rocof, P_dev = res["t"], res["f"], res["rocof"], res["P_dev"]
    mask_post = t >= t_evento
    colapso = bool(res.get("colapso", False))

    if colapso:
        k_c = res["k_colapso"]
        f_nadir = f[k_c]
        t_nadir = t[k_c] - t_evento
        rocof_max = np.abs(rocof[mask_post][:int(2.0 / (t[1] - t[0]))]).max()
        t_rec = np.nan  # no recupera: protección actuaría (deslastre), fuera de alcance del modelo
        P_pico = np.abs(P_dev[t <= t[k_c]]).max()
        dt = t[1] - t[0]
        E_inyectada = np.sum(np.clip(P_dev[t <= t[k_c]], 0, None)) * dt / 3600.0
    else:
        idx_nadir = np.argmin(f[mask_post])
        f_nadir = f[mask_post][idx_nadir]
        t_nadir = t[mask_post][idx_nadir] - t_evento
        rocof_max = np.abs(rocof[mask_post][:int(2.0 / (t[1] - t[0]))]).max() if mask_post.any() else 0.0
        bajo_umbral = np.where((t >= t_evento) & (f < umbral))[0]
        t_rec = 0.0 if len(bajo_umbral) == 0 else t[bajo_umbral[-1]] - t_evento
        P_pico = np.abs(P_dev[mask_post]).max()
        dt = t[1] - t[0]
        E_inyectada = np.sum(np.clip(P_dev[mask_post], 0, None)) * dt / 3600.0  # MWh (P_dev>0 = inyección)

    return {
        "f_nadir_Hz": f_nadir,
        "t_nadir_s": t_nadir,
        "ROCOF_max_Hz_s": rocof_max,
        "t_recuperacion_s": t_rec,
        "P_pico_MW": P_pico,
        "E_inyectada_MWh": E_inyectada,
        "colapso": colapso,
    }
