#!/usr/bin/env python3
"""
gemelos.py — Los 4 gemelos digitales (BESS, ZypyZape FW, ZypyZape+Quijote,
Synchronous Condenser), cada uno expuesto como una función de control
p_dev_func(k, t_k, df_pu, dfdt, estado) -> (P_dev_MW, estado) compatible
con red.simular_red().

Nota de honestidad: los parámetros de ZypyZape vienen de los valores que
Víctor citó en su propuesta (00_CONTEXT_ZYPYZAPE.txt, v4.7/v4.8), no del
repo real (esta sesión no tiene acceso al repositorio). Están marcados
como ASUNCIÓN donde no hay forma de verificarlos aquí.
"""
import numpy as np
from dataclasses import dataclass, field


# ============================================================
# 1) BESS
# ============================================================
@dataclass
class ParamsBESS:
    P_MW: float = 1.0
    E_MWh: float = 2.0
    eta_rt: float = 0.88          # round-trip
    c_rate_max: float = 1.0       # 1C
    t_resp_s: float = 0.1
    K_droop: float = 20.0         # MW por pu de desviación (saturado a P_MW)
    DoD_max: float = 0.80
    degradacion_pct_anual: float = 2.0


def estado_bess_init(p: ParamsBESS):
    return {"SOC": 0.5, "P_filt": 0.0}


def control_bess(k, t_k, df_pu, dfdt, estado, p: ParamsBESS):
    eta_1 = np.sqrt(p.eta_rt)  # reparte la pérdida en carga y descarga
    # respuesta tipo droop + aporte proporcional a RoCoF (acota con P nominal)
    P_obj = np.clip(-p.K_droop * df_pu * p.P_MW / 0.02, -p.P_MW, p.P_MW)
    # límite C-rate
    P_obj = np.clip(P_obj, -p.c_rate_max * p.E_MWh, p.c_rate_max * p.E_MWh)
    # filtro de primer orden (tiempo de respuesta)
    dt = 0.02
    alpha = dt / max(p.t_resp_s, dt)
    P_filt = estado["P_filt"] + alpha * (P_obj - estado["P_filt"])
    # límite por SOC (no descargar bajo 1-DoD_max/2 ni cargar por encima de 1-(1-DoD_max)/2... simplificado)
    soc_min, soc_max = (1 - p.DoD_max) / 2, 1 - (1 - p.DoD_max) / 2
    if P_filt > 0 and estado["SOC"] <= soc_min:
        P_filt = 0.0
    if P_filt < 0 and estado["SOC"] >= soc_max:
        P_filt = 0.0
    # actualizar SOC (P_filt>0 descarga, P_filt<0 carga)
    dE = -P_filt * dt / 3600.0 if P_filt > 0 else -P_filt * eta_1 * dt / 3600.0
    SOC_new = estado["SOC"] + dE / p.E_MWh
    nuevo_estado = {"SOC": np.clip(SOC_new, 0, 1), "P_filt": P_filt}
    P_red = P_filt * eta_1 if P_filt > 0 else P_filt / eta_1  # pérdidas también al inyectar/cargar desde red
    return P_red, nuevo_estado


# ============================================================
# 2) ZypyZape firmware-only (inercia sintética vía rotor eólico)
# ============================================================
@dataclass
class ParamsZZ_FW:
    n_turbinas: int = 10
    P_turbina_MW: float = 2.5
    J_turbina: float = 5.0e6      # kg·m^2  [ASUNCIÓN: valor citado del repo]
    omega_nom: float = 1.57       # rad/s (~15 rpm, turbina típica de 2.5 MW)
    f_ciclo_Hz: float = 0.4       # [ASUNCIÓN: parámetro de control citado]
    P_ZZ_frac: float = 0.13       # fracción de P nominal disponible como inercia sintética [ASUNCIÓN]
    eta_conv: float = 0.95
    K_sintetica: float = 8.0      # ganancia H_efectiva -> respuesta df/dt


def estado_zz_init(p: ParamsZZ_FW):
    return {"omega": np.full(p.n_turbinas, p.omega_nom), "disponible": True}


def control_zz_fw(k, t_k, df_pu, dfdt, estado, p: ParamsZZ_FW, viento_k):
    P_nom_total = p.n_turbinas * p.P_turbina_MW
    # energía cinética total disponible en los rotores (función del viento vía omega)
    # modelo simple: omega escala con v/v_nom entre 0.6 y 1.05 pu
    omega_pu = np.clip(0.6 + 0.45 * (viento_k / 11.4), 0.5, 1.1)
    omega = p.omega_nom * omega_pu
    J_total = p.n_turbinas * p.J_turbina
    # inercia sintética: P = -2*H_zz*S_zz/f0 * df/dt, con H_zz = 0.5*J*omega^2/S_total
    S_total = P_nom_total  # MVA~MW
    H_zz = 0.5 * J_total * np.mean(omega) ** 2 / (S_total * 1e6)  # J/(MW*1e6)=s
    f0 = 50.0
    P_sint = -2 * H_zz * S_total / f0 * dfdt
    # límite por disponibilidad de potencia y por banda de control (P_ZZ_frac)
    P_lim = p.P_ZZ_frac * P_nom_total
    P_dev = np.clip(P_sint * p.eta_conv, -P_lim, P_lim)
    nuevo_estado = dict(estado)
    nuevo_estado["omega"] = omega
    return P_dev, nuevo_estado


# ============================================================
# 3) ZypyZape + Quijote (masa deslizante, J variable)
# ============================================================
@dataclass
class ParamsZZ_Quijote(ParamsZZ_FW):
    m_quijote_kg: float = 4.0 * 1000  # [ASUNCIÓN] escalado a 4000 kg/pala (orden "400 kg" x~10 por 3 palas aprox, ver nota)
    r_min: float = 5.0
    r_max: float = 55.0
    n_turbinas_equipadas: int = 5     # N_Q de 10
    t_actuacion_s: float = 1.5        # tiempo de desplazamiento radial completo
    eta_actuador: float = 0.85


def estado_zzq_init(p: ParamsZZ_Quijote):
    base = estado_zz_init(p)
    base["r_quijote"] = np.full(p.n_turbinas_equipadas, (p.r_min + p.r_max) / 2)
    base["W_hurto_acum"] = 0.0
    base["W_actuador_acum"] = 0.0
    return base


def control_zzq(k, t_k, df_pu, dfdt, estado, p: ParamsZZ_Quijote, viento_k):
    dt = 0.02
    # J adicional por masa deslizante: J_Q = m_q * r^2 (por pala/turbina equipada)
    # ante déficit (df_pu<0, dfdt<0), desplaza masa HACIA FUERA (aumenta J -> más energía cinética a liberar)
    objetivo_r = p.r_max if df_pu < -0.0005 else (p.r_min if df_pu > 0.0005 else estado["r_quijote"])
    dr_max = (p.r_max - p.r_min) / p.t_actuacion_s * dt
    r_new = estado["r_quijote"] + np.clip(objetivo_r - estado["r_quijote"], -dr_max, dr_max)

    J_Q_por_turbina = p.m_quijote_kg * np.mean(r_new) ** 2  # kg*m^2 (simplificado, 1 masa equivalente/turbina)
    J_total_zz = p.n_turbinas * p.J_turbina
    J_total_Q = p.n_turbinas_equipadas * J_Q_por_turbina
    J_total = J_total_zz + J_total_Q

    omega_pu = np.clip(0.6 + 0.45 * (viento_k / 11.4), 0.5, 1.1)
    omega = p.omega_nom * omega_pu
    P_nom_total = p.n_turbinas * p.P_turbina_MW
    S_total = P_nom_total
    H_zz = 0.5 * J_total * np.mean(omega) ** 2 / (S_total * 1e6)
    f0 = 50.0
    P_sint = -2 * H_zz * S_total / f0 * dfdt
    P_lim = p.P_ZZ_frac * P_nom_total * (1 + p.n_turbinas_equipadas / p.n_turbinas)  # algo más de margen por Quijote
    P_dev_bruto = np.clip(P_sint * p.eta_conv, -P_lim, P_lim)

    # coste del actuador (W_actuador): mover la masa radialmente contra la fuerza centrífuga
    dr = r_new - estado["r_quijote"]
    F_centrifuga_aprox = p.m_quijote_kg * np.mean(omega) ** 2 * np.mean(r_new)
    W_actuador = np.abs(F_centrifuga_aprox * np.sum(np.abs(dr))) / p.eta_actuador / 1e6  # MJ aprox -> tratamos como MW*dt
    P_actuador = W_actuador / dt if dt > 0 else 0.0
    P_actuador_MW = np.clip(P_actuador, 0, p.P_ZZ_frac * P_nom_total * 0.2)

    P_dev = P_dev_bruto - P_actuador_MW  # el actuador consume, resta a lo inyectado

    nuevo_estado = dict(estado)
    nuevo_estado["omega"] = omega
    nuevo_estado["r_quijote"] = r_new
    nuevo_estado["W_hurto_acum"] = estado["W_hurto_acum"] + max(P_dev_bruto, 0) * dt / 3600.0
    nuevo_estado["W_actuador_acum"] = estado["W_actuador_acum"] + P_actuador_MW * dt / 3600.0
    return P_dev, nuevo_estado


# ============================================================
# 4) Synchronous condenser
# ============================================================
@dataclass
class ParamsSyncCond:
    S_MVA: float = 100.0
    H: float = 5.0
    eta: float = 0.975
    f0: float = 50.0


def estado_sc_init(p: ParamsSyncCond):
    return {}


def control_sync_condenser(k, t_k, df_pu, dfdt, estado, p: ParamsSyncCond):
    # respuesta de inercia pura, instantánea (física del rotor, sin control digital)
    P_inj = -2 * p.H * p.S_MVA / p.f0 * dfdt
    P_dev = P_inj * p.eta
    return P_dev, estado
