#!/usr/bin/env python3
"""
economia.py — CAPEX, OPEX, ROI, LCOS, payback para los 4 sistemas,
con dos correcciones respecto a la propuesta original (acordadas con
Víctor antes de construir los gemelos):

  1. El precio FCR NO es una constante de 112.000 €/MW·año cuando se
     despliega a escala de flota. Se modela como una curva de demanda
     con saturación: precio(Q) cae a medida que crece la oferta
     acumulada Q (MW) que compite por un mercado de tamaño finito
     (la reserva de frecuencia que la red necesita, fijada por el
     mayor incidente N-1, no por cuánta oferta exista).

  2. Se añade una partida de CAPEX "acceso OEM / certificación firmware"
     a ZypyZape (FW y Quijote), ausente en la propuesta original, que
     recoge el coste no-técnico identificado como posible cuello de
     botella (H3 en la propuesta).

Todas las cifras de CAPEX/OPEX son rangos de ingeniería (no medidos),
tomados de la propuesta de Víctor y de referencias de mercado típicas
(Lazard LCOE/LCOS, EPRI); se usa el valor central de cada rango salvo
que se indique lo contrario. Están marcadas como estimaciones.
"""
import numpy as np
import pandas as pd

# ------------------------------------------------------------------
# CAPEX / OPEX por sistema (€/MW, €/MW·año), valores centrales de los
# rangos de la propuesta original
# ------------------------------------------------------------------
SISTEMAS_ECO = {
    "BESS": {
        "capex_mw": 1_100_000,     # medio del rango 850k-1.35M €/MW
        "capex_oem": 0,
        "opex_mw_anio": 17_000,    # medio del rango 8.5k-27k
        "vida_anios": 12,
        "eta_rt": 0.88,
        "degradacion_pct_anual": 2.5,
    },
    "ZZ_FW": {
        "capex_mw": 11_000,        # medio del rango 2k-20k €/MW
        "capex_oem": 8_000,        # NUEVO: acceso OEM / recertificación firmware [ESTIMACIÓN]
        "opex_mw_anio": 3_500,     # medio del rango 1k-5k ("1.000-5.000 actualizaciones")
        "vida_anios": 20,
        "eta_rt": None,
        "degradacion_pct_anual": 0.0,
    },
    "ZZ_Quijote": {
        "capex_mw": 40_000,        # medio del rango 20k-60k €/MW
        "capex_oem": 8_000,        # mismo acceso OEM que FW + certificación IEC 61400-1 adicional
        "capex_certificacion_extra": 60_000,  # 1-5 M€ repartido en módulo de 25 MW -> ~40-200k€/MW, tomamos medio bajo
        "opex_mw_anio": 3_500 * 2,  # 2-5% CAPEX/año ~ más que FW por actuadores
        "vida_anios": 17,
        "eta_rt": None,
        "degradacion_pct_anual": 0.0,
    },
    "SyncCond": {
        "capex_mw": 275_000,       # medio del rango 200k-350k €/MW
        "capex_oem": 0,
        "opex_mw_anio": 4_500,     # medio del rango 2k-7k
        "vida_anios": 35,
        "eta_rt": 0.975,
        "degradacion_pct_anual": 0.0,
    },
}

CAPEX_TOTAL_MW = {
    sis: v["capex_mw"] + v.get("capex_oem", 0) + v.get("capex_certificacion_extra", 0)
    for sis, v in SISTEMAS_ECO.items()
}

# ------------------------------------------------------------------
# Mercado de servicios de frecuencia/inercia: curva de demanda con
# saturación (CORRECCIÓN 1)
# ------------------------------------------------------------------
PRECIO_ESCASEZ = 112_000.0   # €/MW·año, precio FCR Alemania 2026 citado en la propuesta
PRECIO_SUELO = 20_000.0      # €/MW·año, estimación de coste marginal de proveer el servicio
Q50_MW = 3_000.0             # MW, tamaño aprox. del mercado FCR continental citado en la propuesta
                              # (precio cae a medio camino entre techo y suelo cuando la oferta
                              # acumulada iguala el tamaño actual del mercado)
Q_MAX_MERCADO_MW = 15_000.0  # MW, techo físico estimado: la reserva de frecuencia
                              # (FCR+aFRR+inercia sintética) que la red europea entera
                              # puede necesitar, fijada por el tamaño del mayor incidente
                              # N-1 y los márgenes ENTSO-E, no por cuánta oferta exista.
                              # [ESTIMACIÓN] — por encima de este volumen, MW adicionales
                              # retrofitados NO tienen comprador para este servicio
                              # concreto, por barato que sea el CAPEX.


def precio_fcr(Q_mw):
    """Precio de equilibrio (€/MW·año) para una oferta acumulada Q_mw (MW).
    Modelo de saturación hiperbólica: precio decrece monótonamente con Q,
    tiende a PRECIO_ESCASEZ para Q->0 y a PRECIO_SUELO para Q->inf.
    (Esto por sí solo NO limita el tamaño del mercado — ver Q_MAX_MERCADO_MW
    y ingreso_anual_total, que sí lo hace.)"""
    Q = np.asarray(Q_mw, dtype=float)
    return PRECIO_SUELO + (PRECIO_ESCASEZ - PRECIO_SUELO) / (1 + Q / Q50_MW)


def ingreso_anual_total(Q_mw):
    """Ingreso total del mercado (M€/año) bajo precio uniforme de cierre
    (todas las unidades cobran el mismo precio marginal, como en las
    subastas FCR europeas): ingreso = Q_efectivo * precio(Q_efectivo).
    Q_efectivo = min(Q_mw, Q_MAX_MERCADO_MW): la capacidad que exceda el
    techo físico del mercado no cobra nada por ESTE servicio (aunque siga
    vendiendo energía normalmente, eso es otro ingreso, no este)."""
    Q_ef = np.minimum(np.asarray(Q_mw, dtype=float), Q_MAX_MERCADO_MW)
    return Q_ef * precio_fcr(Q_ef) / 1e6


def payback_simple(capex_mw, opex_mw_anio, ingreso_mw_anio):
    flujo_neto = ingreso_mw_anio - opex_mw_anio
    if flujo_neto <= 0:
        return np.inf
    return capex_mw / flujo_neto


def roi_horizonte(capex_mw, opex_mw_anio, ingreso_mw_anio, anios, tasa=0.06):
    """ROI acumulado a 'anios' descontando flujos (VAN acumulado / CAPEX)."""
    flujo = ingreso_mw_anio - opex_mw_anio
    van = sum(flujo / (1 + tasa) ** a for a in range(1, anios + 1)) - capex_mw
    return van / capex_mw * 100.0


def lcos(capex_mw, opex_mw_anio, energia_mwh_anio, vida_anios, tasa=0.06):
    """LCOS simplificado = (CAPEX + sum OPEX descontado) / (sum energía descontada).
    Para los sistemas de pura inercia/potencia (SyncCond) sin energía
    almacenada significativa, se reporta como NaN (la métrica no aplica)."""
    if energia_mwh_anio is None or energia_mwh_anio <= 0:
        return np.nan
    costes = capex_mw + sum(opex_mw_anio / (1 + tasa) ** a for a in range(1, vida_anios + 1))
    energia = sum(energia_mwh_anio / (1 + tasa) ** a for a in range(1, vida_anios + 1))
    return costes / energia


def tabla_base(Q_mw_mercado_actual=25.0, ciclos_dia=1.0, energia_evento_mwh=None):
    """Tabla CAPEX/OPEX/ROI/LCOS/payback con el mercado en su tamaño actual
    (deployment pequeño: un parque de 25 MW retrofit), precio casi en el
    techo de escasez."""
    filas = []
    precio = float(precio_fcr(Q_mw_mercado_actual))
    for sis, v in SISTEMAS_ECO.items():
        capex = CAPEX_TOTAL_MW[sis]
        opex = v["opex_mw_anio"]
        pb = payback_simple(capex, opex, precio)
        roi15 = roi_horizonte(capex, opex, precio, 15)
        roi10 = roi_horizonte(capex, opex, precio, 10)
        roi20 = roi_horizonte(capex, opex, precio, 20)
        filas.append({
            "sistema": sis,
            "CAPEX_EUR_MW": capex,
            "OPEX_EUR_MW_anio": opex,
            "precio_FCR_EUR_MW_anio": precio,
            "payback_anios": pb,
            "ROI_10a_pct": roi10,
            "ROI_15a_pct": roi15,
            "ROI_20a_pct": roi20,
            "vida_util_anios": v["vida_anios"],
        })
    return pd.DataFrame(filas)


def escenario_flota(n_molinos=416_532, p_molino_mw=2.5, capex_retrofit_mw=None,
                     frac_quijote=0.0):
    """Reescritura de la Parte 9 con la curva de demanda saturante y el
    techo físico del mercado. Compara dos estrategias:
      (a) retrofit de TODA la flota (lo que proponía el texto original)
      (b) retrofit SOLO hasta el tamaño del mercado (Q_MAX_MERCADO_MW) —
          la cantidad económicamente racional
    """
    Q_total = n_molinos * p_molino_mw
    capex_mw = capex_retrofit_mw if capex_retrofit_mw is not None else (
        CAPEX_TOTAL_MW["ZZ_FW"] * (1 - frac_quijote) + CAPEX_TOTAL_MW["ZZ_Quijote"] * frac_quijote
    )
    ingreso_total_Meur = float(ingreso_anual_total(Q_total))  # ya acota a Q_MAX_MERCADO_MW internamente
    precio_final = float(precio_fcr(min(Q_total, Q_MAX_MERCADO_MW)))

    capex_flota_completa_Meur = Q_total * capex_mw / 1e6
    payback_flota_completa = (capex_flota_completa_Meur / ingreso_total_Meur
                               if ingreso_total_Meur > 0 else np.inf)

    Q_racional = min(Q_total, Q_MAX_MERCADO_MW)
    capex_racional_Meur = Q_racional * capex_mw / 1e6
    ingreso_racional_Meur = float(ingreso_anual_total(Q_racional))
    payback_racional = (capex_racional_Meur / ingreso_racional_Meur
                         if ingreso_racional_Meur > 0 else np.inf)

    return {
        "Q_total_flota_MW": Q_total,
        "Q_max_mercado_MW": Q_MAX_MERCADO_MW,
        "precio_final_EUR_MW_anio": precio_final,
        "ingreso_total_mercado_Meur_anio": ingreso_total_Meur,
        "— retrofit de toda la flota —": "",
        "capex_flota_completa_Meur": capex_flota_completa_Meur,
        "payback_anios_flota_completa": payback_flota_completa,
        "pct_flota_sin_comprador": 100 * (1 - Q_racional / Q_total),
        "— retrofit solo hasta saturación del mercado —": "",
        "MW_racional_a_retrofitar": Q_racional,
        "capex_racional_Meur": capex_racional_Meur,
        "payback_anios_racional": payback_racional,
    }


def punto_de_cruce_roi(sis_a="ZZ_FW", sis_b="BESS", anios=15, tasa=0.06,
                        precios=None):
    """P3: ¿a qué precio FCR se cruza el ROI de dos sistemas?"""
    if precios is None:
        precios = np.linspace(5_000, 150_000, 400)
    va = SISTEMAS_ECO[sis_a]
    vb = SISTEMAS_ECO[sis_b]
    roi_a = np.array([roi_horizonte(CAPEX_TOTAL_MW[sis_a], va["opex_mw_anio"], p, anios, tasa) for p in precios])
    roi_b = np.array([roi_horizonte(CAPEX_TOTAL_MW[sis_b], vb["opex_mw_anio"], p, anios, tasa) for p in precios])
    # el ROI de ZZ ya es mayor en casi todo el rango; buscamos si invierte signo la diferencia
    diff = roi_a - roi_b
    cruce = None
    for i in range(1, len(precios)):
        if diff[i - 1] == 0 or np.sign(diff[i]) != np.sign(diff[i - 1]):
            cruce = precios[i]
            break
    return precios, roi_a, roi_b, cruce
