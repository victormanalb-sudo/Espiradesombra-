#!/usr/bin/env python3
"""
run_montecarlo.py — Barrido Monte Carlo para los 4 sistemas x 3 niveles de
perturbación, guarda resultados crudos y agregados en CSV.

Nota de alcance: la propuesta original pedía 100 réplicas x 1h simulada.
Aquí se usan 25 réplicas x 200s (ventana que cubre el escalón en t=30s y
los eventos de viento en t=45-55s y t=65-75s) por motivos de tiempo de
cómputo en esta sesión. El método es el mismo; solo cambia N y el horizonte.
"""
import sys, time
import numpy as np
import pandas as pd
sys.path.insert(0, "/home/claude/gemelos_comparativos/src")
import wrapper as w

N_REPLICAS = 25
HORIZONTE_S = 200.0
DT = 0.02
DELTAS_P = [-100.0, -200.0, -500.0]

OUT_DIR = "/home/claude/gemelos_comparativos/out/tablas"


def main():
    filas = []
    t0 = time.time()
    for dP in DELTAS_P:
        for sis in w.SISTEMAS:
            for s in range(N_REPLICAS):
                m, _, _ = w.simular(sis, dP=dP, seed=s, horizonte_s=HORIZONTE_S, dt=DT)
                filas.append(m)
    df = pd.DataFrame(filas)
    df.to_csv(f"{OUT_DIR}/metricas_fisicas_crudo.csv", index=False)

    agg = df.groupby(["sistema", "dP_MW"]).agg(
        f_nadir_Hz_media=("f_nadir_Hz", "mean"),
        f_nadir_Hz_std=("f_nadir_Hz", "std"),
        t_nadir_s_media=("t_nadir_s", "mean"),
        ROCOF_max_Hz_s_media=("ROCOF_max_Hz_s", "mean"),
        ROCOF_max_Hz_s_std=("ROCOF_max_Hz_s", "std"),
        t_recuperacion_s_media=("t_recuperacion_s", "mean"),
        P_pico_MW_media=("P_pico_MW", "mean"),
        E_inyectada_MWh_media=("E_inyectada_MWh", "mean"),
        frac_colapso=("colapso", "mean"),
    ).reset_index()
    agg.to_csv(f"{OUT_DIR}/metricas_fisicas_agregadas.csv", index=False)
    print(agg.to_string(index=False))
    print(f"\nTotal: {len(filas)} simulaciones en {time.time()-t0:.1f}s")


if __name__ == "__main__":
    main()
