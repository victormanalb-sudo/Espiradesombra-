#!/usr/bin/env python3
"""
wrapper.py — Interfaz común simular(sistema, dP, seed, horizonte) -> métricas
y barrido Monte Carlo sobre el viento.
"""
import numpy as np
from functools import partial
import red
import gemelos as g

SISTEMAS = ["BESS", "ZZ_FW", "ZZ_Quijote", "SyncCond"]

PARAMS = {
    "BESS": g.ParamsBESS(),
    "ZZ_FW": g.ParamsZZ_FW(),
    "ZZ_Quijote": g.ParamsZZ_Quijote(),
    "SyncCond": g.ParamsSyncCond(),
}


def _control_para(sistema, viento):
    p = PARAMS[sistema]
    if sistema == "BESS":
        estado0 = g.estado_bess_init(p)
        def f(k, t_k, df_pu, dfdt, estado):
            return g.control_bess(k, t_k, df_pu, dfdt, estado, p)
    elif sistema == "ZZ_FW":
        estado0 = g.estado_zz_init(p)
        def f(k, t_k, df_pu, dfdt, estado):
            return g.control_zz_fw(k, t_k, df_pu, dfdt, estado, p, viento[k])
    elif sistema == "ZZ_Quijote":
        estado0 = g.estado_zzq_init(p)
        def f(k, t_k, df_pu, dfdt, estado):
            return g.control_zzq(k, t_k, df_pu, dfdt, estado, p, viento[k])
    elif sistema == "SyncCond":
        estado0 = g.estado_sc_init(p)
        def f(k, t_k, df_pu, dfdt, estado):
            return g.control_sync_condenser(k, t_k, df_pu, dfdt, estado, p)
    else:
        raise ValueError(sistema)
    return f, estado0


def simular(sistema, dP=-100.0, seed=0, horizonte_s=200.0, dt=0.02,
            t_evento=30.0, red_params=None):
    """Ejecuta un episodio: red + viento + dispositivo. Devuelve métricas + series."""
    if red_params is None:
        red_params = red.ParametrosRed()
    rng = np.random.default_rng(seed)
    t = np.arange(0.0, horizonte_s, dt)
    viento = red.simular_viento(t, red.ParametrosViento(), rng)
    p_dist = red.perturbacion(t, t_evento=t_evento, dP=dP)

    f, estado0 = _control_para(sistema, viento)
    res = red.simular_red(t, p_dist, f, red_params, estado_dev=estado0)
    m = red.metricas(res, f0=red_params.f0, t_evento=t_evento)
    m["sistema"] = sistema
    m["dP_MW"] = dP
    m["seed"] = seed
    return m, res, viento


def barrido_montecarlo(sistema, dP=-100.0, n_replicas=30, horizonte_s=200.0, dt=0.02):
    filas = []
    for s in range(n_replicas):
        m, _, _ = simular(sistema, dP=dP, seed=s, horizonte_s=horizonte_s, dt=dt)
        filas.append(m)
    return filas
