#!/usr/bin/env python3
import sys
sys.path.insert(0, "/home/claude/gemelos_comparativos/src")
import numpy as np
import pandas as pd
import economia as e

OUT = "/home/claude/gemelos_comparativos/out/tablas"

# 1) Tabla base (deployment pequeño, 25 MW, precio casi de escasez)
tb = e.tabla_base(Q_mw_mercado_actual=25.0)
tb.to_csv(f"{OUT}/economia_base_25MW.csv", index=False)

# 2) Sensibilidad ROI15 vs precio FCR
precios = np.linspace(5_000, 150_000, 60)
filas = []
for p in precios:
    for sis, v in e.SISTEMAS_ECO.items():
        filas.append({
            "precio_EUR_MW_anio": p,
            "sistema": sis,
            "ROI_15a_pct": e.roi_horizonte(e.CAPEX_TOTAL_MW[sis], v["opex_mw_anio"], p, 15),
        })
pd.DataFrame(filas).to_csv(f"{OUT}/sensibilidad_roi_precio.csv", index=False)

# 3) Escenario de flota global (corregido)
filas_flota = []
for frac_q, nombre in [(0.0, "100% firmware-only"), (1.0, "100% Quijote")]:
    r = e.escenario_flota(frac_quijote=frac_q)
    r["estrategia"] = nombre
    filas_flota.append(r)
pd.DataFrame(filas_flota).to_csv(f"{OUT}/escenario_flota_corregido.csv", index=False)

# 4) Puntos de cruce de ROI vs BESS
cruces = {}
for sis in ["ZZ_FW", "ZZ_Quijote", "SyncCond"]:
    _, _, _, c = e.punto_de_cruce_roi(sis, "BESS")
    cruces[sis] = c
pd.DataFrame([cruces]).to_csv(f"{OUT}/puntos_cruce_roi_vs_bess.csv", index=False)

print("Tabla base:")
print(tb.round(1).to_string(index=False))
print("\nEscenario flota:")
print(pd.DataFrame(filas_flota).to_string(index=False))
print("\nCruces ROI vs BESS (€/MW·año):", cruces)
print("\nCSV escritos en", OUT)
