#!/usr/bin/env python3
"""
figuras.py — Genera las figuras del informe. Paleta categórica fija
(orden validado anti-daltonismo, ver skill dataviz / palette.md):
  BESS -> azul, ZZ_FW -> naranja, ZZ_Quijote -> aqua, SyncCond -> amarillo
Un eje por gráfico (nunca doble eje); leyenda siempre presente para >=2 series.
"""
import sys
sys.path.insert(0, "/home/claude/gemelos_comparativos/src")
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

import wrapper as w
import economia as e

OUT = "/home/claude/gemelos_comparativos/out/figuras"

COLOR = {
    "BESS": "#2a78d6",
    "ZZ_FW": "#eb6834",
    "ZZ_Quijote": "#1baf7a",
    "SyncCond": "#eda100",
}
NOMBRE = {
    "BESS": "BESS (batería)",
    "ZZ_FW": "ZypyZape firmware-only",
    "ZZ_Quijote": "ZypyZape + Quijote",
    "SyncCond": "Condensador síncrono",
}
TEXT_PRIMARY = "#0b0b0b"
TEXT_SECONDARY = "#52514e"
SURFACE = "#fcfcfb"

plt.rcParams.update({
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "axes.edgecolor": "#d8d7d2",
    "axes.labelcolor": TEXT_PRIMARY,
    "text.color": TEXT_PRIMARY,
    "xtick.color": TEXT_SECONDARY,
    "ytick.color": TEXT_SECONDARY,
    "axes.grid": True,
    "grid.color": "#ebeae5",
    "grid.linewidth": 0.8,
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def fig_frecuencia_tiempo():
    fig, ax = plt.subplots(figsize=(8, 4.5))
    series = {}
    for sis in w.SISTEMAS:
        m, res, _ = w.simular(sis, dP=-100.0, seed=1, horizonte_s=90.0, dt=0.02)
        series[sis] = res
        ax.plot(res["t"], res["f"], color=COLOR[sis], lw=1.8, label=NOMBRE[sis])
    ax.axhline(49.9, color=TEXT_SECONDARY, lw=1, ls="--", alpha=0.6)
    ax.text(2, 49.87, "umbral 49.9 Hz", color=TEXT_SECONDARY, fontsize=8, va="top")
    ax.axvline(30, color=TEXT_SECONDARY, lw=1, ls=":", alpha=0.6)
    ax.set_xlabel("tiempo (s)")
    ax.set_ylabel("frecuencia (Hz)")
    ax.set_title("f(t) ante ΔP = −100 MW en t = 30 s")
    ax.legend(frameon=False, loc="lower right")

    # inset: zoom al nadir, donde se aprecian las diferencias reales entre sistemas
    axins = ax.inset_axes([0.08, 0.08, 0.32, 0.38])
    for sis in w.SISTEMAS:
        res = series[sis]
        mask = (res["t"] >= 31.5) & (res["t"] <= 33.5)
        axins.plot(res["t"][mask], res["f"][mask], color=COLOR[sis], lw=1.8)
    axins.set_xticks([])
    axins.set_yticks([])
    axins.set_title("zoom al nadir", fontsize=7, color=TEXT_SECONDARY)
    for spine in axins.spines.values():
        spine.set_edgecolor("#c8c7c2")

    fig.tight_layout()
    fig.savefig(f"{OUT}/01_frecuencia_tiempo.png", dpi=150)
    plt.close(fig)


def fig_rocof_vs_dp(df_agg):
    fig, ax = plt.subplots(figsize=(7, 4.5))
    dPs = sorted(df_agg["dP_MW"].unique())
    x = np.arange(len(dPs))
    width = 0.19
    for i, sis in enumerate(w.SISTEMAS):
        vals = [df_agg[(df_agg.sistema == sis) & (df_agg.dP_MW == dp)]["ROCOF_max_Hz_s_media"].values[0]
                for dp in dPs]
        ax.bar(x + (i - 1.5) * width, vals, width, color=COLOR[sis], label=NOMBRE[sis])
    ax.set_xticks(x)
    ax.set_xticklabels([f"{int(d)} MW" for d in dPs])
    ax.set_xlabel("ΔP (pérdida de generación)")
    ax.set_ylabel("ROCOF máx. (Hz/s)")
    ax.set_title("ROCOF máximo vs tamaño de la perturbación")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/02_rocof_vs_dp.png", dpi=150)
    plt.close(fig)


def fig_capex_opex():
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    sistemas = list(e.SISTEMAS_ECO.keys())
    capex = [e.CAPEX_TOTAL_MW[s] for s in sistemas]
    opex = [e.SISTEMAS_ECO[s]["opex_mw_anio"] for s in sistemas]
    colores = [COLOR[s] for s in sistemas]

    axes[0].bar(range(len(sistemas)), capex, color=colores)
    axes[0].set_yscale("log")
    axes[0].set_xticks(range(len(sistemas)))
    axes[0].set_xticklabels([NOMBRE[s] for s in sistemas], rotation=20, ha="right", fontsize=8)
    axes[0].set_ylabel("€ / MW  (escala log)")
    axes[0].set_title("CAPEX total por MW")
    for i, v in enumerate(capex):
        axes[0].text(i, v * 1.15, f"{v/1000:.0f}k€", ha="center", fontsize=8, color=TEXT_SECONDARY)

    axes[1].bar(range(len(sistemas)), opex, color=colores)
    axes[1].set_yscale("log")
    axes[1].set_xticks(range(len(sistemas)))
    axes[1].set_xticklabels([NOMBRE[s] for s in sistemas], rotation=20, ha="right", fontsize=8)
    axes[1].set_ylabel("€ / MW·año  (escala log)")
    axes[1].set_title("OPEX anual por MW")
    for i, v in enumerate(opex):
        axes[1].text(i, v * 1.15, f"{v/1000:.1f}k€", ha="center", fontsize=8, color=TEXT_SECONDARY)

    fig.tight_layout()
    fig.savefig(f"{OUT}/03_capex_opex.png", dpi=150)
    plt.close(fig)


def fig_roi_horizonte():
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    anios = np.arange(1, 21)
    precio = float(e.precio_fcr(25.0))  # mercado actual, deployment pequeño (25 MW)
    for sis, v in e.SISTEMAS_ECO.items():
        roi = [e.roi_horizonte(e.CAPEX_TOTAL_MW[sis], v["opex_mw_anio"], precio, a) for a in anios]
        ax.plot(anios, roi, color=COLOR[sis], lw=1.8, label=NOMBRE[sis])
    ax.axhline(0, color=TEXT_SECONDARY, lw=1)
    ax.set_xlabel("horizonte (años)")
    ax.set_ylabel("ROI acumulado (%)")
    ax.set_yscale("symlog")
    ax.set_title("ROI acumulado vs horizonte (precio FCR actual, deployment de 25 MW)")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/04_roi_horizonte.png", dpi=150)
    plt.close(fig)


def fig_sensibilidad_roi_precio():
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    precios = np.linspace(5_000, 150_000, 300)
    for sis, v in e.SISTEMAS_ECO.items():
        roi = [e.roi_horizonte(e.CAPEX_TOTAL_MW[sis], v["opex_mw_anio"], p, 15) for p in precios]
        ax.plot(precios / 1000, roi, color=COLOR[sis], lw=1.8, label=NOMBRE[sis])
    ax.axvline(112, color=TEXT_SECONDARY, lw=1, ls="--", alpha=0.6)
    ax.text(0.78, 0.92, "precio FCR\nactual (112k)", transform=ax.transAxes,
            fontsize=8, color=TEXT_SECONDARY, va="top")
    ax.set_xlabel("precio del servicio (k€ / MW·año)")
    ax.set_ylabel("ROI a 15 años (%)")
    ax.set_yscale("symlog")
    ax.set_title("Sensibilidad: ROI 15a vs precio del servicio de red")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(f"{OUT}/05_sensibilidad_roi_precio.png", dpi=150)
    plt.close(fig)


def fig_saturacion_mercado():
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    Q = np.linspace(1, 50_000, 500)
    precio = e.precio_fcr(np.minimum(Q, e.Q_MAX_MERCADO_MW))
    ax.plot(Q / 1000, precio / 1000, color=COLOR["ZZ_FW"], lw=2)
    ax.axvline(e.Q_MAX_MERCADO_MW / 1000, color=TEXT_SECONDARY, lw=1, ls="--")
    ax.text(e.Q_MAX_MERCADO_MW / 1000 + 0.5, precio.max() / 1000 * 0.9,
            "techo físico del\nmercado estimado\n(15 GW)", fontsize=8, color=TEXT_SECONDARY)
    ax.set_xlabel("oferta acumulada desplegada (GW)")
    ax.set_ylabel("precio de equilibrio (k€ / MW·año)")
    ax.set_title("Curva de saturación del mercado de servicios de frecuencia")
    fig.tight_layout()
    fig.savefig(f"{OUT}/06_saturacion_mercado.png", dpi=150)
    plt.close(fig)


def fig_lcos_bess():
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ciclos = np.array([0.5, 1, 1.5, 2, 3])
    v = e.SISTEMAS_ECO["BESS"]
    energia_anual = [c * 2.0 * 365 * v["eta_rt"] for c in ciclos]  # MWh/año descargados (E_MWh=2.0)
    lcos_vals = [e.lcos(e.CAPEX_TOTAL_MW["BESS"], v["opex_mw_anio"], ea, v["vida_anios"]) for ea in energia_anual]
    ax.plot(ciclos, lcos_vals, color=COLOR["BESS"], lw=2, marker="o", ms=6)
    ax.set_xlabel("ciclos equivalentes / día")
    ax.set_ylabel("LCOS (€ / MWh)")
    ax.set_title("LCOS del BESS vs ciclos diarios\n(ZZ-FW, ZZ-Quijote y SyncCond no almacenan energía: LCOS no aplica)")
    fig.tight_layout()
    fig.savefig(f"{OUT}/07_lcos_bess.png", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    df_agg = pd.read_csv("/home/claude/gemelos_comparativos/out/tablas/metricas_fisicas_agregadas.csv")
    fig_frecuencia_tiempo()
    fig_rocof_vs_dp(df_agg)
    fig_capex_opex()
    fig_roi_horizonte()
    fig_sensibilidad_roi_precio()
    fig_saturacion_mercado()
    fig_lcos_bess()
    print("Figuras generadas en", OUT)
